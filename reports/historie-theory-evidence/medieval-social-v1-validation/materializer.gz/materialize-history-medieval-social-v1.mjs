#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const readJson = (p) => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));
const writeJson = (p, value) => {
  const file = path.join(root, p);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);
};
const writeText = (p, value) => {
  const file = path.join(root, p);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, value.endsWith('\n') ? value : `${value}\n`);
};
const sorted = (xs) => [...new Set(xs)].sort((a,b) => String(a).localeCompare(String(b), 'nb'));
const upsert = (items, key, incoming) => {
  const map = new Map(items.map((x) => [x[key], x]));
  for (const x of incoming) map.set(x[key], x);
  return [...map.values()].sort((a,b) => String(a[key]).localeCompare(String(b[key]), 'nb'));
};
const sha256 = (p) => crypto.createHash('sha256').update(fs.readFileSync(path.join(root, p))).digest('hex');

const dossierPath = "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json";
const batchId = 'history_medieval_social_economic_legal_evidence_v1';
const date = '2026-07-27';
const requirementIds = [
  'case_req_his_temporal_sequence',
  'case_req_his_actor_conflict',
  'case_req_his_source_comparison',
  'case_req_his_comparative_scale'
];

const dossier = {
  "schema_version": "1.0",
  "dossier_id": "history_medieval_social_economic_legal_evidence_v1",
  "subject_id": "historie",
  "geography_id": "geo_no_oslo_akershus",
  "status": "reviewed_source_dossier",
  "accessed_at": "2026-07-27",
  "scope": {
    "qualified_theory_ids": [
      "theory_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "theory_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "theory_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "theory_his_middelalder_kirke_skriftkultur_diplom_og_muntlig_rett",
      "theory_his_middelalder_kirke_handel_handverk_og_bydannelse"
    ],
    "held_back_theory_ids": [
      "theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming"
    ],
    "method_rule": "Ruinstatus, grunnleggelsesdato eller generiske middelalderetiketter kvalifiserer ingen teori. Claims må dokumentere sosial praksis, eiendomsrelasjon, norm og praksis, skriftlig overlevering eller urban materiell kontekst med eksplisitte begrensninger."
  },
  "source_snapshots": [
    {
      "source_id": "src_his_niku_follobane_medieval_oslo",
      "title": "Follobaneprosjektet",
      "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
      "url": "https://www.niku.no/prosjekter/follobaneprosjektet/",
      "supported_dimensions": [
        "household_and_urbanism_claims"
      ],
      "limitations": [
        "Prosjektsiden oppsummerer et stort utgravningsforløp, men erstatter ikke stratigrafiske rapporter, funnkataloger eller kontekstdata for hver struktur og gjenstand.",
        "Utgravningstraseen følger et moderne jernbaneinngrep og er derfor et selektivt utsnitt av middelalderbyen, ikke et representativt tverrsnitt av alle hushold eller bydeler."
      ]
    },
    {
      "source_id": "src_his_niku_medieval_town_household",
      "title": "En bygård fra middelalderen",
      "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
      "url": "https://arkeologibloggen.niku.no/en-bygard-fra-middelalderen/",
      "supported_dimensions": [
        "household_and_daily_life_claims"
      ],
      "limitations": [
        "Feltbloggen er faglig formidling fra prosjektet, men gir ikke en fullstendig bygningsarkeologisk analyse eller kvantifisert oversikt over alle bygårder.",
        "Funksjoner som søvn, matlaging, lagring, husdyrhold og produksjon er arkeologiske tolkninger av en bygårdstype og kan ikke uten videre overføres til hvert rom eller alle hushold."
      ]
    },
    {
      "source_id": "src_his_niku_urban_living_human_remains",
      "title": "Menneskelige levninger fra middelalderbyen Oslo",
      "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
      "url": "https://www.niku.no/prosjekter/urban-living-menneskelige-levninger-middelalderbyen-oslo/",
      "supported_dimensions": [
        "demography_and_life_course_claims"
      ],
      "limitations": [
        "Prosjektet er oppgitt som under utvikling, og siden dokumenterer forskningsspørsmål og metodeambisjon snarere enn ferdige befolkningsestimater.",
        "Biografier fra bevarte menneskelige levninger er avhengige av gravplass, bevaring, utgravningshistorie og analyseutvalg og kan ikke behandles som en folketelling av middelalderbyen."
      ]
    },
    {
      "source_id": "src_his_oslo_byleksikon_gamle_aker",
      "title": "Gamle Aker kirke",
      "publisher": "Oslo byleksikon",
      "url": "https://oslobyleksikon.no/side/Gamle_Aker_kirke",
      "supported_dimensions": [
        "rural_parish_property_and_jurisdiction_claims"
      ],
      "limitations": [
        "Oppslagsverket oppsummerer en lang eierskaps- og brukshistorie og viser ikke dokumentkjeden for hvert årstall eller eierskifte på siden.",
        "At kirken var fylkeskirke og klostereiendom dokumenterer institusjonell tilknytning, men ikke automatisk lokal rettspraksis, husholdsstørrelse eller bøndenes faktiske plikter."
      ]
    },
    {
      "source_id": "src_his_oslo_byleksikon_aker_gard",
      "title": "Aker gård",
      "publisher": "Oslo byleksikon",
      "url": "https://oslobyleksikon.no/side/Aker_g%C3%A5rd",
      "supported_dimensions": [
        "land_property_and_absence_claims"
      ],
      "limitations": [
        "Plasseringen av gårdstunene er usikker fordi tuftene ikke er funnet; stedet kan derfor ikke brukes som direkte arkeologisk husholdscase.",
        "Opplysningene om gave og senere kronovertakelse identifiserer rettighetsoverføring, men dokumenterer ikke i seg selv driftsform, landskyld eller brukernes forhandlinger."
      ]
    },
    {
      "source_id": "src_his_snl_hovedoya_monastery_estates",
      "title": "Hovedøya kloster",
      "publisher": "Store norske leksikon",
      "url": "https://snl.no/Hoved%C3%B8ya_kloster",
      "supported_dimensions": [
        "land_gifts_and_patronage_claims"
      ],
      "limitations": [
        "Artikkelen sammenfatter klosterets rikdom og jordegods, men gir ikke en fullstendig eiendomsliste eller dokumenterer hvordan hver gård ble drevet.",
        "At jordegods ble samlet gjennom gaver viser patronasjerelasjoner, men gavenes motiver og de lokale brukernes vilkår må undersøkes i diplomer, jordebøker og rettskilder."
      ]
    },
    {
      "source_id": "src_his_oslo_byleksikon_nonneseter",
      "title": "Nonneseter",
      "publisher": "Oslo byleksikon",
      "url": "https://oslobyleksikon.no/side/Nonneseter",
      "supported_dimensions": [
        "property_network_claims"
      ],
      "limitations": [
        "Tallet på 272 gårder gjelder et oppsummert tidspunkt og beskriver ikke eiendomsnettverkets sammensetning, varighet eller inntekter for hvert gods.",
        "Klosterets eierskap dokumenterer registrerte rettigheter, men ikke direkte kontroll, arbeidsdeling eller forholdene for brukere på de enkelte gårdene."
      ]
    },
    {
      "source_id": "src_his_nb_bylaw_1276",
      "title": "Dei norske byane og Bylova av 1276",
      "publisher": "Nasjonalbiblioteket",
      "url": "https://www.nb.no/historier-fra-samlingen/dei-norske-byane-og-bylova-av-1276/",
      "supported_dimensions": [
        "law_urban_order_and_trade_claims"
      ],
      "limitations": [
        "Formidlingssiden oppsummerer lovens temaer og geografiske bruk, men er ikke en full tekstkritisk utgave av alle manuskriptvarianter.",
        "Lovregler er normative utsagn; de dokumenterer ikke uten videre etterlevelse, håndheving eller lik praksis i alle byene som brukte loven."
      ]
    },
    {
      "source_id": "src_his_nb_norse_law_manuscripts",
      "title": "Norrøne lovmanuskripter i 600 år",
      "publisher": "Nasjonalbiblioteket",
      "url": "https://www.nb.no/hva-skjer/norrone-lovmanuskripter-i-600-ar/",
      "supported_dimensions": [
        "law_text_transmission_claims"
      ],
      "limitations": [
        "Arrangementssiden gir en kuratert oversikt over samlingen og teksthistorien, men erstatter ikke kodikologisk og paleografisk analyse av hvert manuskript.",
        "De eldste bevarte manuskriptene er yngre enn lovenes ikrafttredelse; bevarte tillegg og oversettelser viser bruk og endring, men ikke hele den tapte overleveringen."
      ]
    },
    {
      "source_id": "src_his_nb_medieval_manuscripts",
      "title": "Middelalder",
      "publisher": "Nasjonalbiblioteket",
      "url": "https://www.nb.no/samlingen/privatarkiv/middelalder/",
      "supported_dimensions": [
        "writing_diploma_and_survival_claims"
      ],
      "limitations": [
        "Samlingsguiden beskriver Nasjonalbibliotekets bevarte materiale, som ikke er identisk med den opprinnelige middelalderske bok- og dokumentproduksjonen i Oslo.",
        "Mange manuskripter er gått tapt eller bare bevart som fragmenter, og flere latinske manuskripter kom til Norge etter middelalderen; proveniens må kontrolleres for hvert objekt."
      ]
    },
    {
      "source_id": "src_his_snl_hallvardskirken",
      "title": "Hallvardskirken",
      "publisher": "Store norske leksikon",
      "url": "https://snl.no/Hallvardskirken",
      "supported_dimensions": [
        "cathedral_and_bishopric_claims"
      ],
      "limitations": [
        "Dateringen av byggestart og ferdigstillelse er delvis formulert som sannsynlighet og terminus ante quem, ikke som eksakte byggeår.",
        "Katedralens forbindelse til bispegården lokaliserer kirkelig institusjonsmakt, men dokumenterer ikke konkrete dommer, kunngjøringer eller jurisdiksjonskonflikter."
      ]
    },
    {
      "source_id": "src_his_niku_bispevika_b8b",
      "title": "Arkeologiske undersøkelser i Bispevika, tomt B8b",
      "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
      "url": "https://www.niku.no/prosjekter/arkeologiske-undersokelser-i-bispevika-tomt-b8b/",
      "supported_dimensions": [
        "harbor_royal_manor_and_mariakirken_claims"
      ],
      "limitations": [
        "Prosjektsiden kombinerer resultater fra 2022–2023 med funn fra undersøkelser på 1970- og 1990-tallet; hvert funn må spores til riktig undersøkelse og kontekst.",
        "Bryggefundamenter og skipsvrak dokumenterer havneaktivitet, men alene ikke handelsvolum, vareeier, opprinnelse eller identiteten til aktørene."
      ]
    },
    {
      "source_id": "src_his_niku_bispevika_syd",
      "title": "Bispevika syd: Kloakk, pest og forlatte skip",
      "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
      "url": "https://www.niku.no/prosjekter/bispevika-syd-kloakk-pest-og-forlatte-skip/",
      "supported_dimensions": [
        "harbor_material_and_preservation_claims"
      ],
      "limitations": [
        "Den gode organiske bevaringen i leire er en lokal deposisjons- og bevaringssituasjon og kan ikke generaliseres til hele byen eller alle varetyper.",
        "Avfall, tau, tømmer, brygger og vrak viser aktivitet og materialstrømmer, men krever kontekstanalyse før de knyttes til bestemte håndverk, hushold eller handelsnettverk."
      ]
    },
    {
      "source_id": "src_his_snl_mariakirken_oslo",
      "title": "Mariakirken – Oslo",
      "publisher": "Store norske leksikon",
      "url": "https://snl.no/Mariakirken_-_Oslo",
      "supported_dimensions": [
        "royal_church_claims"
      ],
      "limitations": [
        "Artikkelen identifiserer Mariakirken som kongens kirke, men denne funksjonen varierte gjennom en lang bygnings- og institusjonshistorie.",
        "Kongelig tilknytning og beliggenhet ved havna dokumenterer en institusjonell knutepunktfunksjon, men ikke alle administrative handlinger eller handelsforbindelser."
      ]
    },
    {
      "source_id": "src_his_oslo_middelalderbyen_official",
      "title": "Om Middelalderbyen",
      "publisher": "Oslo kommune",
      "url": "https://www.oslo.kommune.no/natur-kultur-og-fritid/kunst-og-kultur/middelalderbyen/om-middelalderbyen",
      "supported_dimensions": [
        "urbanization_and_institutional_topography_claims"
      ],
      "limitations": [
        "Kommunens formidlingsside sammenfatter byens utvikling og dagens kulturmiljøforvaltning, men er ikke en utgravningsrapport eller full historiografisk drøfting.",
        "Opplysningene om handel, befolkning og kongelig/kirkelig topografi er overordnede og må ikke brukes til presise demografiske eller kausale beregninger uten fagkilder."
      ]
    }
  ],
  "production_decisions": [
    "Middelalderbyen Oslo og Hovedøya kloster gjenbrukes bare der nye claims dokumenterer andre faglige dimensjoner enn ruinens eksistens og arkeologisk formation.",
    "Gamle Aker kirke, Hallvardskatedralen, Bjørvika og Mariakirkeruinen oppgraderes bare med minst to validerte claim–source–place-koblinger hver.",
    "Svartedauden holdes tilbake fordi V1 ikke har to stedsspesifikke Oslo/Akershus-caser som dokumenterer dødelighet, ødegårder eller institusjonsendring med tilstrekkelig proveniens."
  ]
};
const newSources = [
  {
    "source_id": "src_his_niku_follobane_medieval_oslo",
    "title": "Follobaneprosjektet",
    "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
    "source_type": "archaeological_project_page",
    "url": "https://www.niku.no/prosjekter/follobaneprosjektet/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1000,
      "to": 2025
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.niku_follobane",
        "household_and_urbanism_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Prosjektsiden oppsummerer et stort utgravningsforløp, men erstatter ikke stratigrafiske rapporter, funnkataloger eller kontekstdata for hver struktur og gjenstand.",
      "Utgravningstraseen følger et moderne jernbaneinngrep og er derfor et selektivt utsnitt av middelalderbyen, ikke et representativt tverrsnitt av alle hushold eller bydeler."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Primær prosjektkilde fra ansvarlig arkeologisk institusjon for utgravningsperiode og registrerte struktur- og funntyper."
    }
  },
  {
    "source_id": "src_his_niku_medieval_town_household",
    "title": "En bygård fra middelalderen",
    "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
    "source_type": "archaeological_field_blog",
    "url": "https://arkeologibloggen.niku.no/en-bygard-fra-middelalderen/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1000,
      "to": 1500
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.niku_medieval_household",
        "household_and_daily_life_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": "2019-12-03",
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Feltbloggen er faglig formidling fra prosjektet, men gir ikke en fullstendig bygningsarkeologisk analyse eller kvantifisert oversikt over alle bygårder.",
      "Funksjoner som søvn, matlaging, lagring, husdyrhold og produksjon er arkeologiske tolkninger av en bygårdstype og kan ikke uten videre overføres til hvert rom eller alle hushold."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Nær feltkontekst og eksplisitt beskrivelse av hvordan bygningsenheter og gårdsrom brukes til å rekonstruere middelaldersk dagligliv."
    }
  },
  {
    "source_id": "src_his_niku_urban_living_human_remains",
    "title": "Menneskelige levninger fra middelalderbyen Oslo",
    "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
    "source_type": "bioarchaeological_research_project",
    "url": "https://www.niku.no/prosjekter/urban-living-menneskelige-levninger-middelalderbyen-oslo/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1000,
      "to": null
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.niku_urban_living",
        "demography_and_life_course_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Prosjektet er oppgitt som under utvikling, og siden dokumenterer forskningsspørsmål og metodeambisjon snarere enn ferdige befolkningsestimater.",
      "Biografier fra bevarte menneskelige levninger er avhengige av gravplass, bevaring, utgravningshistorie og analyseutvalg og kan ikke behandles som en folketelling av middelalderbyen."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Primær forskningsbeskrivelse fra NIKU for bioarkeologisk rekonstruksjon av individuelle livsløp og urbanisering."
    }
  },
  {
    "source_id": "src_his_oslo_byleksikon_gamle_aker",
    "title": "Gamle Aker kirke",
    "publisher": "Oslo byleksikon",
    "source_type": "local_history_reference",
    "url": "https://oslobyleksikon.no/side/Gamle_Aker_kirke",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1100,
      "to": null
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.gamle_aker",
        "rural_parish_property_and_jurisdiction_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Oppslagsverket oppsummerer en lang eierskaps- og brukshistorie og viser ikke dokumentkjeden for hvert årstall eller eierskifte på siden.",
      "At kirken var fylkeskirke og klostereiendom dokumenterer institusjonell tilknytning, men ikke automatisk lokal rettspraksis, husholdsstørrelse eller bøndenes faktiske plikter."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Redigert lokalhistorisk oppslagsverk med presise institusjons- og eierskapsopplysninger om et canonical sted."
    }
  },
  {
    "source_id": "src_his_oslo_byleksikon_aker_gard",
    "title": "Aker gård",
    "publisher": "Oslo byleksikon",
    "source_type": "local_history_reference",
    "url": "https://oslobyleksikon.no/side/Aker_g%C3%A5rd",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1100,
      "to": 1629
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.aker_gard",
        "land_property_and_absence_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Plasseringen av gårdstunene er usikker fordi tuftene ikke er funnet; stedet kan derfor ikke brukes som direkte arkeologisk husholdscase.",
      "Opplysningene om gave og senere kronovertakelse identifiserer rettighetsoverføring, men dokumenterer ikke i seg selv driftsform, landskyld eller brukernes forhandlinger."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Redigert lokalhistorisk oppslagsverk som eksplisitt oppgir både eiendomsoverføring og lokaliseringsusikkerhet."
    }
  },
  {
    "source_id": "src_his_snl_hovedoya_monastery_estates",
    "title": "Hovedøya kloster",
    "publisher": "Store norske leksikon",
    "source_type": "reference_encyclopedia",
    "url": "https://snl.no/Hoved%C3%B8ya_kloster",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1147,
      "to": 1532
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.hovedoya_estates",
        "land_gifts_and_patronage_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": "2025-06-30",
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Artikkelen sammenfatter klosterets rikdom og jordegods, men gir ikke en fullstendig eiendomsliste eller dokumenterer hvordan hver gård ble drevet.",
      "At jordegods ble samlet gjennom gaver viser patronasjerelasjoner, men gavenes motiver og de lokale brukernes vilkår må undersøkes i diplomer, jordebøker og rettskilder."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Fagredigert leksikonartikkel med tydelig opplysning om gavebasert oppbygging av omfattende jordegods."
    }
  },
  {
    "source_id": "src_his_oslo_byleksikon_nonneseter",
    "title": "Nonneseter",
    "publisher": "Oslo byleksikon",
    "source_type": "local_history_reference",
    "url": "https://oslobyleksikon.no/side/Nonneseter",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1161,
      "to": 1616
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.nonneseter",
        "property_network_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Tallet på 272 gårder gjelder et oppsummert tidspunkt og beskriver ikke eiendomsnettverkets sammensetning, varighet eller inntekter for hvert gods.",
      "Klosterets eierskap dokumenterer registrerte rettigheter, men ikke direkte kontroll, arbeidsdeling eller forholdene for brukere på de enkelte gårdene."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Redigert lokalhistorisk oppslagsverk med konkret størrelse på Nonneseters eiendomsnettverk og forbindelse til Store Aker."
    }
  },
  {
    "source_id": "src_his_nb_bylaw_1276",
    "title": "Dei norske byane og Bylova av 1276",
    "publisher": "Nasjonalbiblioteket",
    "source_type": "collection_history_article",
    "url": "https://www.nb.no/historier-fra-samlingen/dei-norske-byane-og-bylova-av-1276/",
    "language": "nn",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1276,
      "to": null
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.bylaw_1276",
        "law_urban_order_and_trade_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": "2021-10-06",
      "updated_at": "2023-05-30",
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Formidlingssiden oppsummerer lovens temaer og geografiske bruk, men er ikke en full tekstkritisk utgave av alle manuskriptvarianter.",
      "Lovregler er normative utsagn; de dokumenterer ikke uten videre etterlevelse, håndheving eller lik praksis i alle byene som brukte loven."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Nasjonalbibliotekets kildeformidling knytter Byloven av 1276 til konkrete byregler og stiller eksplisitt spørsmål ved forholdet mellom lov og praksis."
    }
  },
  {
    "source_id": "src_his_nb_norse_law_manuscripts",
    "title": "Norrøne lovmanuskripter i 600 år",
    "publisher": "Nasjonalbiblioteket",
    "source_type": "manuscript_collection_context",
    "url": "https://www.nb.no/hva-skjer/norrone-lovmanuskripter-i-600-ar/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1270,
      "to": 1900
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.law_manuscripts",
        "law_text_transmission_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": "2022",
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Arrangementssiden gir en kuratert oversikt over samlingen og teksthistorien, men erstatter ikke kodikologisk og paleografisk analyse av hvert manuskript.",
      "De eldste bevarte manuskriptene er yngre enn lovenes ikrafttredelse; bevarte tillegg og oversettelser viser bruk og endring, men ikke hele den tapte overleveringen."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Primær samlingskontekst fra Nasjonalbiblioteket for datering, kopiering, tillegg og funksjonsendring i lovmanuskripter."
    }
  },
  {
    "source_id": "src_his_nb_medieval_manuscripts",
    "title": "Middelalder",
    "publisher": "Nasjonalbiblioteket",
    "source_type": "manuscript_collection_guide",
    "url": "https://www.nb.no/samlingen/privatarkiv/middelalder/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 900,
      "to": 1537
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.medieval_manuscripts",
        "writing_diploma_and_survival_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Samlingsguiden beskriver Nasjonalbibliotekets bevarte materiale, som ikke er identisk med den opprinnelige middelalderske bok- og dokumentproduksjonen i Oslo.",
      "Mange manuskripter er gått tapt eller bare bevart som fragmenter, og flere latinske manuskripter kom til Norge etter middelalderen; proveniens må kontrolleres for hvert objekt."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Autoritativ samlingsguide som forklarer skriftkultur, diplomer, segl, materialitet og den fragmentariske overleveringen."
    }
  },
  {
    "source_id": "src_his_snl_hallvardskirken",
    "title": "Hallvardskirken",
    "publisher": "Store norske leksikon",
    "source_type": "reference_encyclopedia",
    "url": "https://snl.no/Hallvardskirken",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1075,
      "to": 1669
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.hallvardskirken",
        "cathedral_and_bishopric_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": "2024-05-30",
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Dateringen av byggestart og ferdigstillelse er delvis formulert som sannsynlighet og terminus ante quem, ikke som eksakte byggeår.",
      "Katedralens forbindelse til bispegården lokaliserer kirkelig institusjonsmakt, men dokumenterer ikke konkrete dommer, kunngjøringer eller jurisdiksjonskonflikter."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Fagredigert leksikonartikkel for Hallvardskirkens funksjon som første domkirke, datering og forbindelse til biskopens residens."
    }
  },
  {
    "source_id": "src_his_niku_bispevika_b8b",
    "title": "Arkeologiske undersøkelser i Bispevika, tomt B8b",
    "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
    "source_type": "archaeological_project_page",
    "url": "https://www.niku.no/prosjekter/arkeologiske-undersokelser-i-bispevika-tomt-b8b/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1200,
      "to": 2023
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.bispevika_b8b",
        "harbor_royal_manor_and_mariakirken_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Prosjektsiden kombinerer resultater fra 2022–2023 med funn fra undersøkelser på 1970- og 1990-tallet; hvert funn må spores til riktig undersøkelse og kontekst.",
      "Bryggefundamenter og skipsvrak dokumenterer havneaktivitet, men alene ikke handelsvolum, vareeier, opprinnelse eller identiteten til aktørene."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Primær prosjektkilde for middelalderhavnens arkeologiske kontekst og den romlige forbindelsen til Kongsgården og Mariakirken."
    }
  },
  {
    "source_id": "src_his_niku_bispevika_syd",
    "title": "Bispevika syd: Kloakk, pest og forlatte skip",
    "publisher": "Norsk institutt for kulturminneforskning (NIKU)",
    "source_type": "archaeological_project_page",
    "url": "https://www.niku.no/prosjekter/bispevika-syd-kloakk-pest-og-forlatte-skip/",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1300,
      "to": 1624
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.bispevika_syd",
        "harbor_material_and_preservation_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Den gode organiske bevaringen i leire er en lokal deposisjons- og bevaringssituasjon og kan ikke generaliseres til hele byen eller alle varetyper.",
      "Avfall, tau, tømmer, brygger og vrak viser aktivitet og materialstrømmer, men krever kontekstanalyse før de knyttes til bestemte håndverk, hushold eller handelsnettverk."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Primær arkeologisk prosjektkilde for havneavsetninger, bevaringsforhold og materiell aktivitet i Bispevika."
    }
  },
  {
    "source_id": "src_his_snl_mariakirken_oslo",
    "title": "Mariakirken – Oslo",
    "publisher": "Store norske leksikon",
    "source_type": "reference_encyclopedia",
    "url": "https://snl.no/Mariakirken_-_Oslo",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1050,
      "to": null
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.mariakirken",
        "royal_church_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": "2026-07",
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Artikkelen identifiserer Mariakirken som kongens kirke, men denne funksjonen varierte gjennom en lang bygnings- og institusjonshistorie.",
      "Kongelig tilknytning og beliggenhet ved havna dokumenterer en institusjonell knutepunktfunksjon, men ikke alle administrative handlinger eller handelsforbindelser."
    ],
    "quality": {
      "tier": "B",
      "rationale": "Fagredigert leksikonartikkel for Mariakirkens status som kongens egen kirke og stedets middelalderske historie."
    }
  },
  {
    "source_id": "src_his_oslo_middelalderbyen_official",
    "title": "Om Middelalderbyen",
    "publisher": "Oslo kommune",
    "source_type": "official_cultural_heritage_page",
    "url": "https://www.oslo.kommune.no/natur-kultur-og-fritid/kunst-og-kultur/middelalderbyen/om-middelalderbyen",
    "language": "nb",
    "geography_ids": [
      "geo_no_oslo_akershus"
    ],
    "temporal_scope": {
      "from": 1000,
      "to": null
    },
    "provenance": {
      "repository_source": "data/fag/historie/source_dossiers/medieval_social_economic_legal_v1.json",
      "extracted_from": [
        "source_snapshots.oslo_middelalderbyen",
        "urbanization_and_institutional_topography_claims"
      ],
      "accessed_at": "2026-07-27"
    },
    "dating": {
      "published_at": null,
      "updated_at": null,
      "accessed_at": "2026-07-27"
    },
    "limitations": [
      "Kommunens formidlingsside sammenfatter byens utvikling og dagens kulturmiljøforvaltning, men er ikke en utgravningsrapport eller full historiografisk drøfting.",
      "Opplysningene om handel, befolkning og kongelig/kirkelig topografi er overordnede og må ikke brukes til presise demografiske eller kausale beregninger uten fagkilder."
    ],
    "quality": {
      "tier": "A",
      "rationale": "Offisiell sted- og kulturmiljøkilde som avgrenser middelalderbyen og beskriver dens handelsmessige og institusjonelle topografi."
    }
  }
];
const newClaims = [
  {
    "claim_id": "claim_his_middelalder_oslo_buildings_wells_cultivation_daily_life",
    "statement": "Utgravningene langs Follobanen i middelalderbyen Oslo avdekket bygninger, gateløp, vannrør, brønner, dyrkningsspor, innhegninger og tusenvis av gjenstander, et sammensatt materiale for å rekonstruere bolig, arbeid og forsyning i byen.",
    "claim_type": "archaeological_assemblage",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1000,
        "to": 2025
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation",
      "em_his_spor_materialitet"
    ],
    "source_ids": [
      "src_his_niku_follobane_medieval_oslo"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Materialet er omfattende, men stammer fra en utbyggingstrasé og dokumenterer ikke alle bydeler eller sosiale grupper likt."
    },
    "alternative_interpretations": [
      "Funnene kan leses som spor etter hushold og dagligliv, men også som infrastruktur, verksteder, avfall og institusjonell aktivitet som må skilles kontekstuelt."
    ]
  },
  {
    "claim_id": "claim_his_middelalder_oslo_town_house_domestic_productive_functions",
    "statement": "En utgravd middelaldersk bygård i Oslo bestod av sammenhørende bygninger og gårdsrom der arkeologene tolker spor etter søvn, matlaging, lagring, husdyrhold, produksjon, kjøp og salg.",
    "claim_type": "household_function_reconstruction",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1100,
        "to": 1400
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation"
    ],
    "source_ids": [
      "src_his_niku_medieval_town_household"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "medium",
      "note": "Funksjonene er arkeologiske tolkninger av bygnings- og gårdsromskontekster; de gir ikke et direkte romskjema eller komplett aktivitetslogg."
    },
    "alternative_interpretations": [
      "Bygården kan analyseres som husholdsenhet, men enkelte rom og aktiviteter kan ha vært delt, kommersielle eller skiftet funksjon over tid."
    ]
  },
  {
    "claim_id": "claim_his_middelalder_oslo_human_remains_individual_biographies",
    "statement": "NIKUs Urban Living-prosjekt bruker menneskelige levninger fra middelalderbyen til å rekonstruere individuelle biografier, opprinnelse og erfaringer med overgangen til urbant liv.",
    "claim_type": "bioarchaeological_method",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1000,
        "to": null
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "em_his_middelalder_oslo",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_arkeologisk_kontekst_formation"
    ],
    "source_ids": [
      "src_his_niku_urban_living_human_remains"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "high",
      "note": "Prosjektet er under utvikling, og bevarte og undersøkte individer er ikke et representativt demografisk utvalg av hele bybefolkningen."
    },
    "alternative_interpretations": [
      "Levningene kan gi kunnskap om livsløp, helse og mobilitet, men de kan ikke uten videre omregnes til samlet befolkning, husholdsstørrelse eller normal livserfaring."
    ]
  },
  {
    "claim_id": "claim_his_gamle_aker_rural_parish_and_lost_farm_context",
    "statement": "Gamle Aker kirke var fylkeskirke for Vingulmark og lå ved Aker gård, men tuftene etter Store og Lille Aker er ikke funnet; stedet gir derfor en institusjonell og landskapsmessig ramme for ruralt liv, ikke direkte husholdsarkeologi.",
    "claim_type": "settlement_context_with_absence",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "gamle_aker_kirke"
      ],
      "case_ids": [
        "case_his_gamle_aker_kirke"
      ],
      "temporal": {
        "from": 1100,
        "to": 1536
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_middelalder_oslo",
      "em_his_kildekritikk_arkiv_spor"
    ],
    "source_ids": [
      "src_his_oslo_byleksikon_gamle_aker",
      "src_his_oslo_byleksikon_aker_gard"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "high",
      "note": "Gårdstunenes plassering er usikker, og kirken kan ikke brukes som fysisk erstatning for de manglende gårdsstrukturene."
    },
    "alternative_interpretations": [
      "Stedet kan belyse sogn, eiendom og institusjonell organisering, men sier lite direkte om familie, kosthold, arbeid og demografisk sammensetning på gårdene."
    ]
  },
  {
    "claim_id": "claim_his_gamle_aker_nonneseter_ownership_1186_1536",
    "statement": "Gamle Aker kirke var eid av Nonneseter kloster fra 1186 til 1536, noe som knytter sognekirken til et langvarig klosterlig eiendoms- og patronasjeforhold.",
    "claim_type": "institutional_ownership_sequence",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "gamle_aker_kirke"
      ],
      "case_ids": [
        "case_his_gamle_aker_kirke"
      ],
      "temporal": {
        "from": 1186,
        "to": 1536
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_kirke_kloster_middelalder"
    ],
    "source_ids": [
      "src_his_oslo_byleksikon_gamle_aker"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "low",
      "note": "Eierskapsperioden er tydelig oppgitt, men kilden beskriver ikke alle inntekter, rettigheter, plikter eller lokale forhandlinger som fulgte eierskapet."
    },
    "alternative_interpretations": [
      "Klostereierskap kan forstås som patronasje og institusjonell integrasjon, men også som en juridisk ramme med varierende praktisk kontroll over tid."
    ]
  },
  {
    "claim_id": "claim_his_aker_farms_gifted_to_nonneseter_then_crown",
    "statement": "Store og Lille Aker ble gitt i gave til Nonneseter kloster og senere overtatt av kongen, en dokumentert overføring av registrerte eiendomsrettigheter mellom kirkelig og kongelig institusjon.",
    "claim_type": "property_transfer",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "gamle_aker_kirke"
      ],
      "case_ids": [
        "case_his_gamle_aker_kirke"
      ],
      "temporal": {
        "from": 1100,
        "to": 1602
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_oslo_byleksikon_aker_gard"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "medium",
      "note": "Kilden oppgir ikke gavebrevets dato, giver, vilkår eller den nøyaktige overtakelsesprosessen, og gårdstuftene er ikke lokalisert."
    },
    "alternative_interpretations": [
      "Overføringen kan leses som patronasje og senere kronovertakelse, men dokumenterer ikke automatisk endring i daglig drift eller brukernes faktiske vilkår."
    ]
  },
  {
    "claim_id": "claim_his_hovedoya_estates_accumulated_through_gifts",
    "statement": "Hovedøya kloster samlet gjennom gaver omfattende jordegods i Oslo-området i løpet av klosterets om lag fire hundre år lange historie.",
    "claim_type": "patronage_accumulation",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hovedoya_kloster"
      ],
      "case_ids": [
        "case_his_hovedoya_kloster"
      ],
      "temporal": {
        "from": 1147,
        "to": 1532
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_kirke_kloster_middelalder",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_snl_hovedoya_monastery_estates"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Oppsummeringen identifiserer gavebasert vekst, men gir ikke en komplett kronologi over givere, gods, motytelser eller forvaltning."
    },
    "alternative_interpretations": [
      "Gavene kan uttrykke religiøs patronasje og minnepraksis, men også familiepolitikk, rettighetsstrategi og institusjonell maktkonsentrasjon."
    ]
  },
  {
    "claim_id": "claim_his_nonneseter_property_network_272_farms_including_aker",
    "statement": "Nonneseter var en stor middelaldersk jordeier og eide på et tidspunkt 272 gårder i østlandsområdet, blant dem Store Aker.",
    "claim_type": "property_network_scale",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "gamle_aker_kirke"
      ],
      "case_ids": [
        "case_his_gamle_aker_kirke"
      ],
      "temporal": {
        "from": 1161,
        "to": 1536
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_kirke_kloster_middelalder",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_oslo_byleksikon_nonneseter",
      "src_his_oslo_byleksikon_gamle_aker"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "medium",
      "note": "Tallet gjelder et oppsummert tidspunkt og gir ikke varighet, inntektsnivå eller eierskapsform for hver av de 272 gårdene."
    },
    "alternative_interpretations": [
      "Eiendomsnettverket kan vise regional institusjonsmakt, men antall gårder er ikke det samme som ensartet direkte drift eller kontroll."
    ]
  },
  {
    "claim_id": "claim_his_oslo_bylaw_1276_urban_rules",
    "statement": "Magnus Lagabøtes bylov fra 1276 ble senere brukt av mer enn ti norske byer og regulerte blant annet handel, brann, vakthold samt lasting og lossing.",
    "claim_type": "normative_legal_code",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1276,
        "to": null
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_middelalder_oslo",
      "em_his_skrift_hand_lesning"
    ],
    "source_ids": [
      "src_his_nb_bylaw_1276"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "low",
      "note": "Kilden oppsummerer lovens hovedtemaer og bruk, men gjengir ikke hele lovteksten eller alle lokale manuskriptvarianter."
    },
    "alternative_interpretations": [
      "Byloven kan leses som en plan for urban orden, men lovbestemmelser dokumenterer ikke i seg selv hvor konsekvent reglene ble praktisert i Oslo."
    ]
  },
  {
    "claim_id": "claim_his_oslo_bylaw_norm_practice_distinction",
    "statement": "Nasjonalbibliotekets formidling av Byloven fremhever spørsmålet om hvor langt lov og faktisk rettspraksis sammenfalt, slik at lovteksten må behandles som norm og forhandlingsramme, ikke som direkte observasjon av bylivet.",
    "claim_type": "source_method_constraint",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1276,
        "to": 1500
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_skrift_hand_lesning",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_nb_bylaw_1276"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "low",
      "note": "Siden reiser eksplisitt problemstillingen, men leverer ikke en samlet empirisk måling av etterlevelse i Oslo."
    },
    "alternative_interpretations": [
      "Avvik mellom lov og praksis kan skyldes manglende håndheving, lokal tilpasning, tapte kilder eller at loven regulerte konflikter nettopp fordi praksis var uensartet."
    ]
  },
  {
    "claim_id": "claim_his_law_manuscripts_postdate_enactment_and_change",
    "statement": "Magnus Lagabøtes lover trådte i kraft i 1270-årene, mens de eldste bevarte lovmanuskriptene i Nasjonalbibliotekets samling er fra 1300-tallet; senere tillegg viser at tekstene ble kopiert og endret i bruk.",
    "claim_type": "manuscript_transmission",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1270,
        "to": 1500
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_skrift_hand_lesning",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_nb_norse_law_manuscripts"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "low",
      "note": "Samlingen er bare en del av den opprinnelige overleveringen, og dateringen av bevarte manuskripter sier ikke når tapte kopier ble produsert eller brukt."
    },
    "alternative_interpretations": [
      "Tillegg kan vise levende rettstekst og tilpasning, men kan også være skrivermerknader, senere kompilasjon eller endret funksjon som må vurderes manuskript for manuskript."
    ]
  },
  {
    "claim_id": "claim_his_hallvardskirken_cathedral_bishop_residence_connection",
    "statement": "Hallvardskirken var Oslos første domkirke, ferdig før 1130, og var fysisk forbundet med Oslo bispegård, biskopens residens.",
    "claim_type": "institutional_topography",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hallvardskirken_oslo"
      ],
      "case_ids": [
        "case_his_hallvardskatedralen"
      ],
      "temporal": {
        "from": 1075,
        "to": 1130
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_lov_ting_og_jurisdiksjon",
      "em_his_kirke_kloster_middelalder",
      "em_his_kongemakt_kirke_konflikt",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_snl_hallvardskirken"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Byggestarten er sannsynlighetsdatert, og den fysiske forbindelsen dokumenterer institusjonell nærhet, ikke konkrete rettsavgjørelser eller jurisdiksjonsgrenser."
    },
    "alternative_interpretations": [
      "Komplekset kan tolkes som kirkelig administrasjons- og autoritetssentrum, men ikke som bevis for at all lokal rett ble avgjort der."
    ]
  },
  {
    "claim_id": "claim_his_hallvardskirken_written_church_administration_context",
    "statement": "Kristningen førte en europeisk skriftkultur til Norge, og den katolske kirkens administrasjon var skriftbasert; Hallvardskirken som domkirke og bispesete inngikk derfor i en institusjonell kontekst for bøker, liturgi og dokumentproduksjon.",
    "claim_type": "writing_institution_context",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hallvardskirken_oslo"
      ],
      "case_ids": [
        "case_his_hallvardskatedralen"
      ],
      "temporal": {
        "from": 1075,
        "to": 1537
      }
    },
    "emne_ids": [
      "em_his_skrift_hand_lesning",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_kirke_kloster_middelalder",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_nb_medieval_manuscripts",
      "src_his_snl_hallvardskirken"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "medium",
      "note": "Kildene dokumenterer den generelle kirkelige skriftkulturen og Hallvardskirkens institusjonsrolle, men ikke en komplett katalog over bøker og dokumenter produsert eller oppbevart akkurat der."
    },
    "alternative_interpretations": [
      "Domkirken kan ha vært et skriftlig administrasjonssentrum, men muntlig kunngjøring, vitner og praksis fortsatte parallelt og må ikke usynliggjøres."
    ]
  },
  {
    "claim_id": "claim_his_medieval_diplomas_contracts_seals_materiality",
    "statement": "Middelalderdiplomer var kontrakter og andre juridiske dokumenter skrevet på enkeltblad og ofte beseglet for å bekrefte utstedernes identitet; form, materiale og segl er derfor del av kildekritikken.",
    "claim_type": "document_form_and_authentication",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hovedoya_kloster"
      ],
      "case_ids": [
        "case_his_hovedoya_kloster"
      ],
      "temporal": {
        "from": 1100,
        "to": 1537
      }
    },
    "emne_ids": [
      "em_his_skrift_hand_lesning",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_spor_materialitet"
    ],
    "source_ids": [
      "src_his_nb_medieval_manuscripts",
      "src_his_snl_hovedoya_monastery_estates"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "medium",
      "note": "Den generelle diplomtypen dokumenterer ikke hvilke konkrete Hovedøya-diplomer som er bevart eller hvilke gaver som bare er kjent gjennom senere oppsummeringer."
    },
    "alternative_interpretations": [
      "Segl og dokumentform kan støtte autentisering og rettighetskrav, men avgjør ikke automatisk at innholdet er fullstendig, upartisk eller praktisert som skrevet."
    ]
  },
  {
    "claim_id": "claim_his_medieval_manuscript_survival_fragmentary_skew",
    "statement": "Mange norske middelaldermanuskripter er gått tapt, mens en del bare overlever som fragmenter brukt i senere bokbind; det bevarte skriftmaterialet fra kirker og klostre er derfor et selektert arkivspor.",
    "claim_type": "archival_survival_constraint",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hallvardskirken_oslo"
      ],
      "case_ids": [
        "case_his_hallvardskatedralen"
      ],
      "temporal": {
        "from": 900,
        "to": 1537
      }
    },
    "emne_ids": [
      "em_his_skrift_hand_lesning",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_kirke_kloster_middelalder"
    ],
    "source_ids": [
      "src_his_nb_medieval_manuscripts"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "low",
      "note": "Nasjonalbibliotekets samling omfatter også materiale som kom til Norge etter middelalderen, så hvert manuskripts proveniens må kontrolleres."
    },
    "alternative_interpretations": [
      "Fragmentarisk overlevering kan skyldes reformasjon, administrativ gjenbruk, slitasje, kassasjon og tilfeldige bevaringsforhold, ikke én samlet sensurmekanisme."
    ]
  },
  {
    "claim_id": "claim_his_hovedoya_estate_history_mediated_by_documentary_survival",
    "statement": "Påstander om Hovedøya klosters gaver og jordegods må leses gjennom en ufullstendig dokumentoverlevering der juridiske dokumenter registrerer rettighetskrav, men ikke hele den løpende driften eller muntlige forhandlingen.",
    "claim_type": "documentary_provenance_constraint",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "hovedoya_kloster"
      ],
      "case_ids": [
        "case_his_hovedoya_kloster"
      ],
      "temporal": {
        "from": 1147,
        "to": 1532
      }
    },
    "emne_ids": [
      "em_his_skrift_hand_lesning",
      "em_his_kildekritikk_arkiv_spor",
      "em_his_middelalder_kirke_jord_eiendom_og_patronasje",
      "em_his_kirke_kloster_middelalder"
    ],
    "source_ids": [
      "src_his_snl_hovedoya_monastery_estates",
      "src_his_nb_medieval_manuscripts"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "high",
      "note": "Den registrerte kilden er en moderne faglig oppsummering, og claimet identifiserer en metodebegrensning snarere enn en komplett katalog over klosterets diplomer."
    },
    "alternative_interpretations": [
      "Dokumenterte gaver kan ha hatt rettslig og symbolsk tyngde samtidig, mens udokumentert bruk, muntlige avtaler og tapte brev kan ha påvirket eiendomsforholdene."
    ]
  },
  {
    "claim_id": "claim_his_bjorvika_medieval_harbor_piers_shipwrecks",
    "statement": "Bispevika B8b var en sentral del av Oslos middelalderhavn fra 1200- til 1600-tallet; tidligere undersøkelser i området fant omfattende bryggefundamenter og fire skipsvrak.",
    "claim_type": "harbor_archaeology",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "bjorvika"
      ],
      "case_ids": [
        "case_his_bjorvika"
      ],
      "temporal": {
        "from": 1200,
        "to": 1600
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation",
      "em_his_spor_materialitet"
    ],
    "source_ids": [
      "src_his_niku_bispevika_b8b"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Prosjektsiden skiller mellom funn fra ulike utgravningsperioder, og skipsvrak og brygger gir ikke alene handelsvolum eller aktøridentitet."
    },
    "alternative_interpretations": [
      "Anleggene kan dokumentere transport og havnebruk, men enkelte konstruksjoner kan ha hatt administrative, kongelige eller lokale forsyningsfunksjoner."
    ]
  },
  {
    "claim_id": "claim_his_bjorvika_organic_harbor_deposits_material_flows",
    "statement": "Utgravningene i Bispevika syd dokumenterte brygger, sjøboder, skipsrester og godt bevarte organiske materialer som bein, tau, flis og tømmer i den tidligere Oslo-havna.",
    "claim_type": "material_flow_assemblage",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "bjorvika"
      ],
      "case_ids": [
        "case_his_bjorvika"
      ],
      "temporal": {
        "from": 1300,
        "to": 1624
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation",
      "em_his_spor_materialitet"
    ],
    "source_ids": [
      "src_his_niku_bispevika_syd"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Materialene er bevart under særlige leirforhold og representerer deponering og tap like mye som planlagt handel eller produksjon."
    },
    "alternative_interpretations": [
      "Avsetningene kan vise vare- og aktivitetsstrømmer, men også avfall, reparasjon, forlatte fartøy og havnemiljøets vedlikehold."
    ]
  },
  {
    "claim_id": "claim_his_middelalder_oslo_streets_infrastructure_permanent_urban_settlement",
    "statement": "Bygninger, gateløp, eiendomsgrenser, brønner og vannrør fra utgravningene i middelalderbyen viser varig og organisert urban bosetting, ikke bare et kortvarig markedssted.",
    "claim_type": "urban_infrastructure",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "middelalder_oslo"
      ],
      "case_ids": [
        "case_his_middelalderbyen_oslo"
      ],
      "temporal": {
        "from": 1000,
        "to": 1500
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation"
    ],
    "source_ids": [
      "src_his_niku_follobane_medieval_oslo",
      "src_his_oslo_middelalderbyen_official"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Arkeologiske strukturer dokumenterer bymessig organisering, men alene ikke hvilke politiske beslutninger eller handelsprosesser som forårsaket bydannelsen."
    },
    "alternative_interpretations": [
      "Fast infrastruktur kan være resultat av kongelig og kirkelig institusjonsbygging, husholdsbehov, handel eller flere sammenvevde prosesser."
    ]
  },
  {
    "claim_id": "claim_his_mariakirken_kings_church_at_ora",
    "statement": "Mariakirken var kongens egen kirke og lå ved Kongsgården på Øra i den sørlige delen av middelalderbyen.",
    "claim_type": "royal_institutional_anchor",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "mariakirken_ruin_oslo"
      ],
      "case_ids": [
        "case_his_mariakirkeruinen"
      ],
      "temporal": {
        "from": 1050,
        "to": 1500
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_kongemakt_kirke_konflikt",
      "em_his_kirke_kloster_middelalder",
      "em_his_middelalder_oslo"
    ],
    "source_ids": [
      "src_his_snl_mariakirken_oslo",
      "src_his_oslo_middelalderbyen_official"
    ],
    "confidence": "high",
    "uncertainty": {
      "level": "medium",
      "note": "Betegnelsen kongens kirke dekker en lang historie og dokumenterer ikke uendret funksjon, bemanning eller kongelig nærvær gjennom hele perioden."
    },
    "alternative_interpretations": [
      "Kirken kan forstås som et kongelig-religiøst sentrum, men dens betydning for bydannelse må undersøkes sammen med havn, bosetting, administrasjon og andre kirker."
    ]
  },
  {
    "claim_id": "claim_his_mariakirken_royal_manor_harbor_connection",
    "statement": "Bryggeanleggene i Bispevika settes arkeologisk i sammenheng med Kongsgården på Øra, mens Mariakirken lå ved kongsgården; stedet knytter dermed kongelig institusjonstopografi til havneområdet.",
    "claim_type": "harbor_institution_connection",
    "scope": {
      "geography_ids": [
        "geo_no_oslo_akershus"
      ],
      "place_ids": [
        "mariakirken_ruin_oslo"
      ],
      "case_ids": [
        "case_his_mariakirkeruinen"
      ],
      "temporal": {
        "from": 1200,
        "to": 1600
      }
    },
    "emne_ids": [
      "em_his_middelalder_kirke_handel_handverk_og_bydannelse",
      "em_his_kongemakt_kirke_konflikt",
      "em_his_middelalder_oslo",
      "em_his_arkeologisk_kontekst_formation"
    ],
    "source_ids": [
      "src_his_niku_bispevika_b8b",
      "src_his_snl_mariakirken_oslo"
    ],
    "confidence": "medium",
    "uncertainty": {
      "level": "high",
      "note": "Forbindelsen mellom deler av bryggeanlegget og Kongsgården er en arkeologisk tolkning, og kilden dokumenterer ikke at alle brygger var kongelig kontrollert."
    },
    "alternative_interpretations": [
      "Den romlige forbindelsen kan vise kongelig forsyning og administrasjon, men også et fleraktør-havneområde med kirkelige, lokale og kommersielle funksjoner."
    ]
  }
];
const theoryBundles = {
  "theory_his_middelalder_kirke_bondehushold_demografi_og_dagligliv": [
    "claim_his_middelalder_oslo_buildings_wells_cultivation_daily_life",
    "claim_his_middelalder_oslo_town_house_domestic_productive_functions",
    "claim_his_middelalder_oslo_human_remains_individual_biographies",
    "claim_his_gamle_aker_rural_parish_and_lost_farm_context"
  ],
  "theory_his_middelalder_kirke_jord_eiendom_og_patronasje": [
    "claim_his_gamle_aker_nonneseter_ownership_1186_1536",
    "claim_his_aker_farms_gifted_to_nonneseter_then_crown",
    "claim_his_hovedoya_estates_accumulated_through_gifts",
    "claim_his_nonneseter_property_network_272_farms_including_aker"
  ],
  "theory_his_middelalder_kirke_lov_ting_og_jurisdiksjon": [
    "claim_his_oslo_bylaw_1276_urban_rules",
    "claim_his_oslo_bylaw_norm_practice_distinction",
    "claim_his_law_manuscripts_postdate_enactment_and_change",
    "claim_his_hallvardskirken_cathedral_bishop_residence_connection"
  ],
  "theory_his_middelalder_kirke_skriftkultur_diplom_og_muntlig_rett": [
    "claim_his_hallvardskirken_written_church_administration_context",
    "claim_his_medieval_diplomas_contracts_seals_materiality",
    "claim_his_medieval_manuscript_survival_fragmentary_skew",
    "claim_his_hovedoya_estate_history_mediated_by_documentary_survival"
  ],
  "theory_his_middelalder_kirke_handel_handverk_og_bydannelse": [
    "claim_his_bjorvika_medieval_harbor_piers_shipwrecks",
    "claim_his_bjorvika_organic_harbor_deposits_material_flows",
    "claim_his_middelalder_oslo_streets_infrastructure_permanent_urban_settlement",
    "claim_his_mariakirken_kings_church_at_ora",
    "claim_his_mariakirken_royal_manor_harbor_connection"
  ]
};
const theoryMeta = {
  "theory_his_middelalder_kirke_bondehushold_demografi_og_dagligliv": {
    "rationale": "Middelalderbyen Oslo dokumenterer bygningsenheter, brønner, dyrkningsspor, aktivitetsrom og menneskelige levninger som indirekte kilder til arbeid, kosthold, livsløp og dagligliv. Gamle Aker gir en ruralt-kirkelig kontrast der den manglende gårdslokaliteten gjør det mulig å prøve hvor langt institusjons- og landskapskilder kan bære husholdsfortolkning.",
    "limitations": [
      "Utgravningstraseer, bevarte gravplasser og enkeltstudier er selektive utvalg og kan ikke brukes som en representativ demografisk telling av hele Oslo/Akershus.",
      "Gamle Aker-casen dokumenterer sogn, eiendom og landskap, men ikke direkte husholdsstørrelse, arbeidsdeling eller kosthold på de tapte Aker-gårdene."
    ],
    "alternative_interpretations": [
      "Materialet kan rekonstruere hverdagspraksis og livsløp, men de samme strukturene og levningene kan også uttrykke verksted, institusjon, avfall, sykdomsseleksjon og skiftende bruk."
    ],
    "disconfirmation_conditions": [
      "Anvendelsen svekkes dersom bygningsfunksjoner, biologiske profiler eller gårdskontekst generaliseres til normalhushold uten stratigrafi, utvalgsanalyse og eksplisitt demografisk usikkerhet."
    ]
  },
  "theory_his_middelalder_kirke_jord_eiendom_og_patronasje": {
    "rationale": "Gamle Aker og Aker-gårdene dokumenterer gave, klostereierskap og senere kronovertakelse, mens Hovedøya viser gavebasert akkumulering av omfattende jordegods. Sammen gjør casene det mulig å skille registrerte rettigheter, patronasje og institusjonell nettverksmakt fra faktisk drift og brukernes vilkår.",
    "limitations": [
      "Oppslagskildene gir ikke komplette gavebrev, jordebøker, landskyldserier eller lokale tvister for hvert gods og tidspunkt.",
      "Antall gårder og formelt eierskap må ikke likestilles med ensartet direkte kontroll, økonomisk avkastning eller uendrede leieforhold."
    ],
    "alternative_interpretations": [
      "Jordgaver kan forstås som religiøs patronasje og minneinvestering, men også som familiepolitikk, rettighetsstrategi, beskyttelse og overføring av inntektskrav."
    ],
    "disconfirmation_conditions": [
      "Anvendelsen svekkes dersom registrert eierskap behandles som bevis på faktisk drift uten dokumenter om brukere, avgifter, arv, motytelser og konflikt."
    ]
  },
  "theory_his_middelalder_kirke_lov_ting_og_jurisdiksjon": {
    "rationale": "Byloven av 1276 og dens senere manuskriptoverlevering dokumenterer normative regler for urban orden samt forskjellen mellom lovtekst og praksis. Hallvardskirken og forbindelsen til bispegården lokaliserer et kirkelig institusjonssentrum, slik at kongelig bylov, tekstbruk og kirkelig autoritet kan sammenlignes uten å gjøre én arena til hele rettssystemet.",
    "limitations": [
      "Casene dokumenterer lovtekst, manuskriptoverlevering og institusjonell topografi, men ikke konkrete tingmøter, domsserier eller fullstendige jurisdiksjonskonflikter i Oslo.",
      "Katedralens og bispegårdens nærhet viser institusjonsmakt, men ikke at all kirkelig eller lokal rett ble avgjort på dette stedet."
    ],
    "alternative_interpretations": [
      "Byloven kan leses som kongelig standardisering, men også som en forhandlingsramme som ble tilpasset lokale praksiser, mens kirkelig autoritet kunne overlappe og konkurrere med andre rettsfora."
    ],
    "disconfirmation_conditions": [
      "Anvendelsen svekkes dersom normative bestemmelser behandles som direkte observasjon av praksis, eller dersom ting, byrett, kirkerett og kongelig jurisdiksjon blandes uten egne kilder."
    ]
  },
  "theory_his_middelalder_kirke_skriftkultur_diplom_og_muntlig_rett": {
    "rationale": "Hallvardskirken som domkirke og Hovedøya som kloster plasserer skriftbasert kirkeadministrasjon, diplomer, segl og eiendomsdokumentasjon i konkrete institusjoner. Lovmanuskriptenes senere kopier, tillegg og fragmentariske overlevering viser samtidig at skrift ikke var statisk eller fullstendig og fortsatt må leses mot muntlig kunngjøring og praksis.",
    "limitations": [
      "V1 mangler komplette lokale bok- og arkivkataloger for Hallvardskirken og Hovedøya og bruker derfor nasjonale samlingskilder som en eksplisitt begrenset overleveringsramme.",
      "Bevarte diplomer og manuskripter favoriserer institusjonelle og juridiske handlinger og gir svakere tilgang til uformelle avtaler, muntlige normer og ikke-skriftkyndige aktører."
    ],
    "alternative_interpretations": [
      "Skrift kan forstås som stabilisering og autentisering av rettigheter, men også som en selektiv maktteknologi som levde sammen med eder, vitner, kunngjøring og senere kopiering."
    ],
    "disconfirmation_conditions": [
      "Anvendelsen svekkes dersom manuskript, diplom, kopi, fragment og moderne utgave behandles som samme kilde, eller dersom muntlig praksis utledes uten egne spor."
    ]
  },
  "theory_his_middelalder_kirke_handel_handverk_og_bydannelse": {
    "rationale": "Bjørvikas brygger, skipsvrak og organiske havneavsetninger dokumenterer transport- og materialstrømmer, mens Middelalderbyens gater, eiendomsgrenser, brønner og bygninger viser varig urban organisering. Mariakirken og Kongsgårdens forbindelse til havna gjør det mulig å prøve hvordan handel, kongelige institusjoner og fast bosetting virket sammen i bydannelsen.",
    "limitations": [
      "Havneanlegg og importerte eller deponerte materialer dokumenterer ikke automatisk handelsvolum, vareeier, opprinnelse eller markedsorganisering.",
      "Utgravningene følger moderne inngrep og særlige bevaringsforhold; håndverk og varig bosetting må dokumenteres gjennom verkstedspor, avfall, bygninger og serier, ikke enkeltsaker alene."
    ],
    "alternative_interpretations": [
      "Bydannelsen kan forklares gjennom handel og sjøforbindelser, men materialet støtter også en flerkausal modell med kongemakt, kirke, hushold, forsyning og administrasjon."
    ],
    "disconfirmation_conditions": [
      "Anvendelsen svekkes dersom hvert bryggefunn klassifiseres som kommersiell handel, eller dersom urban infrastruktur brukes som eneste årsak til byvekst uten aktør- og kronologikilder."
    ]
  }
};

writeJson(dossierPath, dossier);

const claimsPath = 'data/fag/historie/claims_historie_canonical_v1.json';
const sourcesPath = 'data/fag/historie/sources_historie_canonical_v1.json';
const evidencePath = 'data/fag/historie/place_evidence_historie_v1.json';
const registryPath = 'data/fag/historie/theory_evidence_historie_canonical_v1.json';
const profilePath = 'data/fag/profiles/historie/oslo_akershus/profile.json';

const claimsDoc = readJson(claimsPath);
const sourcesDoc = readJson(sourcesPath);
const evidenceDoc = readJson(evidencePath);
const registry = readJson(registryPath);
const profile = readJson(profilePath);

sourcesDoc.sources = upsert(sourcesDoc.sources || [], 'source_id', newSources);
claimsDoc.claims = upsert(claimsDoc.claims || [], 'claim_id', newClaims);

const evidenceLinks = newClaims.map((claim, index) => ({
  evidence_id: `evidence_his_medieval_social_${String(index + 1).padStart(2, '0')}`,
  profile_id: profile.profile_id,
  geography_id: 'geo_no_oslo_akershus',
  place_id: claim.scope.place_ids[0],
  case_id: claim.scope.case_ids[0],
  emne_ids: claim.emne_ids,
  claim_id: claim.claim_id,
  source_ids: claim.source_ids,
  support_type: claim.source_ids.length > 1 ? 'corroborated' : 'direct_single_source',
  validation_status: 'validated_pilot',
  limitations_inherited: true,
  note: 'Middelalder sosial-, økonomi- og rettsevidens V1: kildeformspesifikk claim–source–place-kobling med eksplisitt usikkerhet og alternative fortolkninger.'
}));
evidenceDoc.evidence_links = upsert(evidenceDoc.evidence_links || [], 'evidence_id', evidenceLinks);

const claimById = new Map(claimsDoc.claims.map((x) => [x.claim_id, x]));
const evidenceByClaim = new Map(evidenceDoc.evidence_links.map((x) => [x.claim_id, x]));
function makeEntry(theoryId, claimIds) {
  const selected = claimIds.map((id) => claimById.get(id));
  if (selected.some((x) => !x)) throw new Error(`${theoryId} has missing selected claims`);
  const meta = theoryMeta[theoryId];
  return {
    theory_id: theoryId,
    status: 'evidence_ready',
    scope_status: 'multi_case_geographic_pilot',
    universalization_status: 'provisional_not_universal',
    claim_ids: claimIds,
    source_ids: sorted(selected.flatMap((x) => x.source_ids || [])),
    case_ids: sorted(selected.flatMap((x) => x.scope?.case_ids || [])),
    place_ids: sorted(selected.flatMap((x) => x.scope?.place_ids || [])),
    emne_ids: sorted(selected.flatMap((x) => x.emne_ids || [])),
    evidence_link_ids: sorted(selected.map((x) => evidenceByClaim.get(x.claim_id)?.evidence_id).filter(Boolean)),
    evidence_dimensions: [
      'documented_application',
      'limitation_test',
      'alternative_interpretation',
      'multi_case_comparison',
      'new_claim_source_case_foundation',
      'medieval_source_type_specific_evidence'
    ],
    rationale: meta.rationale,
    limitations: meta.limitations,
    alternative_interpretations: meta.alternative_interpretations,
    disconfirmation_conditions: meta.disconfirmation_conditions,
    scope_note: 'Dette er et fler-case evidensgrunnlag i Oslo/Akershus og er ikke universelt bevis for teoriens gyldighet på tvers av andre perioder, geografier, aktørgrupper og kildetyper.'
  };
}
const entries = Object.entries(theoryBundles).map(([theoryId, claimIds]) => makeEntry(theoryId, claimIds));
registry.entries = upsert(registry.entries || [], 'theory_id', entries);
registry.completion = {
  ...(registry.completion || {}),
  total_theories: 230,
  qualifying_entries: registry.entries.length,
  ratio: Math.round((registry.entries.length / 230) * 1000) / 1000,
  pilot_target: registry.completion?.pilot_target ?? 10,
  universal_target_ratio: 1,
  universal_status: registry.entries.length === 230 ? 'COMPLETE' : 'INCOMPLETE'
};

const caseUpdates = {
  case_his_gamle_aker_kirke: {
    place_ids: ['gamle_aker_kirke'],
    emne_ids: [
      'em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv',
      'em_his_middelalder_kirke_jord_eiendom_og_patronasje',
      'em_his_middelalder_kirke_lov_ting_og_jurisdiksjon',
      'em_his_middelalder_oslo',
      'em_his_kildekritikk_arkiv_spor',
      'em_his_skrift_hand_lesning'
    ],
    role: 'newly_validated'
  },
  case_his_hallvardskatedralen: {
    place_ids: ['hallvardskirken_oslo'],
    emne_ids: [
      'em_his_middelalder_kirke_lov_ting_og_jurisdiksjon',
      'em_his_middelalder_oslo',
      'em_his_kildekritikk_arkiv_spor',
      'em_his_skrift_hand_lesning',
      'em_his_kirke_kloster_middelalder'
    ],
    role: 'newly_validated'
  },
  case_his_bjorvika: {
    place_ids: ['bjorvika'],
    emne_ids: [
      'em_his_middelalder_kirke_handel_handverk_og_bydannelse',
      'em_his_middelalder_oslo',
      'em_his_arkeologisk_kontekst_formation',
      'em_his_spor_materialitet'
    ],
    role: 'newly_validated'
  },
  case_his_mariakirkeruinen: {
    place_ids: ['mariakirken_ruin_oslo'],
    emne_ids: [
      'em_his_middelalder_kirke_handel_handverk_og_bydannelse',
      'em_his_middelalder_oslo',
      'em_his_kongemakt_kirke_konflikt',
      'em_his_kirke_kloster_middelalder',
      'em_his_arkeologisk_kontekst_formation'
    ],
    role: 'newly_validated'
  },
  case_his_middelalderbyen_oslo: {
    place_ids: ['middelalder_oslo'],
    emne_ids: [
      'em_his_middelalder_kirke_bondehushold_demografi_og_dagligliv',
      'em_his_middelalder_kirke_lov_ting_og_jurisdiksjon',
      'em_his_middelalder_kirke_handel_handverk_og_bydannelse',
      'em_his_middelalder_oslo',
      'em_his_kildekritikk_arkiv_spor',
      'em_his_skrift_hand_lesning',
      'em_his_arkeologisk_kontekst_formation'
    ],
    role: 'expanded'
  },
  case_his_hovedoya_kloster: {
    place_ids: ['hovedoya_kloster'],
    emne_ids: [
      'em_his_middelalder_kirke_jord_eiendom_og_patronasje',
      'em_his_middelalder_oslo',
      'em_his_kildekritikk_arkiv_spor',
      'em_his_skrift_hand_lesning',
      'em_his_kirke_kloster_middelalder'
    ],
    role: 'expanded'
  }
};

for (const profileCase of profile.cases || []) {
  const update = caseUpdates[profileCase.case_id];
  if (!update) continue;
  profileCase.place_ids = sorted([...(profileCase.place_ids || []), ...update.place_ids]);
  profileCase.emne_ids = sorted([...(profileCase.emne_ids || []), ...update.emne_ids]);
  profileCase.case_requirement_ids = requirementIds;
  profileCase.status = 'pilot_validated';
  profileCase.evidence_status = 'claim_source_linked';
  if (update.role === 'newly_validated') {
    profileCase.validation = {
      status: 'validated_case',
      batch_id: batchId,
      validated_at: date,
      minimum_evidence_links: 2,
      source_policy: 'canonical_registry_with_explicit_limitations'
    };
  } else {
    profileCase.validation = profileCase.validation || {
      status: 'validated_case',
      batch_id: batchId,
      validated_at: date,
      minimum_evidence_links: 2,
      source_policy: 'canonical_registry_with_explicit_limitations'
    };
    profileCase.validation.additional_batch_ids = sorted([
      ...(profileCase.validation.additional_batch_ids || []),
      batchId
    ]);
    profileCase.validation.scope_expanded_at = date;
  }
}

const mappingByEmne = new Map((profile.emne_case_mappings || []).map((x) => [x.emne_id, x]));
for (const claim of newClaims) {
  for (const emneId of claim.emne_ids) {
    const mapping = mappingByEmne.get(emneId);
    if (!mapping) throw new Error(`Missing reverse profile mapping for ${emneId}`);
    mapping.case_ids = sorted([...(mapping.case_ids || []), ...claim.scope.case_ids]);
  }
}
profile.emne_case_mappings = [...mappingByEmne.values()].sort((a,b) => String(a.emne_id).localeCompare(String(b.emne_id), 'nb'));
profile.last_updated = date;
profile.evidence_batches = Array.isArray(profile.evidence_batches) ? profile.evidence_batches : [];
profile.evidence_batches = upsert(profile.evidence_batches, 'batch_id', [{
  batch_id: batchId,
  status: 'validated',
  validated_at: date,
  newly_verified_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'newly_validated').map(([id]) => id),
  expanded_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'expanded').map(([id]) => id),
  claim_ids: newClaims.map((x) => x.claim_id),
  source_ids: newSources.map((x) => x.source_id),
  evidence_ids: evidenceLinks.map((x) => x.evidence_id),
  qualified_theory_ids: Object.keys(theoryBundles),
  held_back_theory_ids: ['theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming']
}]);

const verifiedCases = profile.cases.filter((x) => x.evidence_status === 'claim_source_linked');
profile.production_coverage = {
  ...(profile.production_coverage || {}),
  status: 'COMPLETE',
  cases_total: profile.cases.length,
  verified_cases_total: verifiedCases.length,
  claims_total: claimsDoc.claims.length,
  sources_total: sourcesDoc.sources.length,
  evidence_links_total: evidenceDoc.evidence_links.length
};

writeJson(sourcesPath, sourcesDoc);
writeJson(claimsPath, claimsDoc);
writeJson(evidencePath, evidenceDoc);
writeJson(registryPath, registry);
writeJson(profilePath, profile);

const foundationPath = 'reports/historie-profile-evidence/history-profile-evidence-foundation.json';
const foundation = readJson(foundationPath);
foundation.schema_version = '7.0';
foundation.report_id = 'historie_profile_evidence_foundation_v7';
foundation.migration.validated_cases = verifiedCases.length;
foundation.migration.unverified_case_candidates = profile.cases.length - verifiedCases.length;
foundation.inventory = {
  emner: foundation.inventory.emner,
  case_requirements: foundation.inventory.case_requirements,
  profile_cases: profile.cases.length,
  profile_mappings: profile.emne_case_mappings.length,
  claims: claimsDoc.claims.length,
  sources: sourcesDoc.sources.length,
  evidence_links: evidenceDoc.evidence_links.length,
  verified_cases: verifiedCases.length
};
foundation.theory_evidence = {
  qualifying_entries: registry.entries.length,
  total_theories: 230,
  ratio: registry.completion.ratio,
  universal_status: registry.completion.universal_status
};
foundation.medieval_social_economic_legal_v1 = {
  phase_id: batchId,
  newly_validated_cases: 4,
  expanded_cases: 2,
  produced_claims: newClaims.length,
  produced_sources: newSources.length,
  produced_evidence_links: evidenceLinks.length,
  qualified_theories: Object.keys(theoryBundles).length,
  theory_ids: Object.keys(theoryBundles),
  newly_verified_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'newly_validated').map(([id]) => id),
  expanded_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'expanded').map(([id]) => id),
  held_back_theory_ids: ['theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming']
};
writeJson(foundationPath, foundation);
writeText('reports/historie-profile-evidence/history-profile-evidence-foundation.md', `# Historie profil- og evidensgrunnlag V7

- Status: **COMPLETE**
- Fullføringsomfang: **minimum_representative_evidence_foundation**
- Profilcaser: **${profile.cases.length}**
- Validerte caser: **${verifiedCases.length}**
- Claims: **${claimsDoc.claims.length}**
- Kilder: **${sourcesDoc.sources.length}**
- Evidenskoblinger: **${evidenceDoc.evidence_links.length}**
- Middelalder sosial-, økonomi- og rettsevidens V1: **4 nye cases / 2 utvidede cases / ${newClaims.length} claims / ${newSources.length} kilder / 5 teoriobjekter**
- Tilbakeholdt teori: **theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming**
- Gjenværende universelt produksjonsgap: **theory_evidence_readiness**
`);

const gapV5Path = 'reports/historie-theory-evidence/history-theory-evidence-gap-inventory-v5.json';
const gap = readJson(gapV5Path);
gap.schema_version = '6.0';
gap.report_id = 'history_theory_evidence_gap_inventory_v6';
gap.baseline = {
  total_theories: 230,
  qualifying_after_medieval_social_economic_legal_v1: registry.entries.length,
  remaining_theories: 230 - registry.entries.length,
  ratio: registry.completion.ratio,
  universal_status: registry.completion.universal_status
};
const medievalCategory = (gap.categories || []).find((x) => x.category_id === 'medieval_social_economic_and_legal_history');
gap.categories = (gap.categories || []).filter((x) => x.category_id !== 'medieval_social_economic_and_legal_history');
gap.partially_resolved_categories = (gap.partially_resolved_categories || []).filter((x) => x.category_id !== 'medieval_social_economic_and_legal_history');
gap.partially_resolved_categories.push({
  category_id: 'medieval_social_economic_and_legal_history',
  status: 'partially_resolved_v1_five_of_six_theories_qualified',
  qualified_theory_ids: Object.keys(theoryBundles),
  remaining_theory_ids: ['theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming'],
  requirement: medievalCategory?.requirement || 'Arkeologiske, diplomatiske, rettslige, demografiske og økonomiske claims som går utover grunnleggelse, statsborg og ruinens etterliv.',
  resolution: {
    phase_id: batchId,
    new_claim_ids: newClaims.map((x) => x.claim_id),
    new_source_ids: newSources.map((x) => x.source_id),
    newly_verified_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'newly_validated').map(([id]) => id),
    expanded_case_ids: Object.entries(caseUpdates).filter(([,x]) => x.role === 'expanded').map(([id]) => id),
    note: 'Fem teoriobjekter er kvalifisert gjennom adskilte husholds-, eiendoms-, lov-, skrift- og by/handelsbaner. Svartedauden holdes tilbake til to stedsspesifikke caser dokumenterer dødelighet, ødegårder eller institusjonsendring med tydelig proveniens.'
  }
});
gap.partially_resolved_categories.sort((a,b) => String(a.category_id).localeCompare(String(b.category_id), 'nb'));
gap.source_fingerprints = Object.fromEntries([
  'data/fag/historie/theory_objects_historie_canonical_v5_5.json',
  registryPath, claimsPath, sourcesPath, evidencePath, profilePath, dossierPath
].map((p) => [p, sha256(p)]));
const gapV6Path = 'reports/historie-theory-evidence/history-theory-evidence-gap-inventory-v6.json';
writeJson(gapV6Path, gap);
writeText('reports/historie-theory-evidence/history-theory-evidence-gap-inventory-v6.md', `# Historie — teori-evidens gap-inventar V6

Status: **ACTIVE_PRODUCTION_DEPENDENCY_MAP**

- Teoriobjekter totalt: **230**
- Kvalifiserende etter middelalder sosial-, økonomi- og rettsevidens V1: **${registry.entries.length}**
- Gjenstående: **${230 - registry.entries.length}**
- Andel: **${Math.round(registry.completion.ratio * 1000) / 10} %**
- Universell status: **${registry.completion.universal_status}**

## Løst i V1

- \`national_political_chronology\`
- \`movement_specific_publics\`
- \`source_method_families\`

## Delvis løst

- \`medieval_social_economic_and_legal_history\`: fem av seks teorier; svartedauden og senmiddelalderens omforming gjenstår
- \`ritual_reception_and_experience\`: to av tre teorier; arkivtaushet gjenstår

## Aktive produksjonsavhengigheter

- \`samisk_minority_and_citizenship\`: requires_new_geographies_claims_and_actor_perspectives
- \`digital_media_and_surveillance\`: requires_new_claims_source_types_and_recent_cases
- \`cold_war_and_global_history\`: requires_new_period_cases_and_geographic_breadth
- \`medieval_social_economic_and_legal_history\`: requires_two_place_specific_black_death_transformation_cases
- \`ritual_reception_and_experience\`: partially_resolved_requires_documented_archival_absence

Rapporten kvalifiserer ingen teori og kan ikke brukes til å omgå evidenskontrakten.
`);

writeText('docs/HISTORY_MEDIEVAL_SOCIAL_ECONOMIC_LEGAL_EVIDENCE_V1.md', `# Historie — middelalderens sosial-, økonomi- og rettsevidens V1

## Formål

Fasen kvalifiserer fem middelalderteorier gjennom nye canonical claims, kilder, cases og place evidence. Ruinstatus, grunnleggelsesdato og generelle middelalderetiketter er ikke brukt som erstatning for sosial, økonomisk eller rettslig dokumentasjon.

## Kvalifiserte teorier

- bondehushold, demografi og dagligliv
- jord, eiendom og patronasje
- lov, ting og jurisdiksjon
- skriftkultur, diplom og muntlig rett
- handel, håndverk og bydannelse

## Evidensbaner

Middelalderbyen og Gamle Aker skiller urban husholdsarkeologi og bioarkeologiske individstudier fra en rural sogne- og eiendomskontekst der gårdstuftene ikke er funnet.

Gamle Aker og Hovedøya dokumenterer gaver, klostereierskap, kronovertakelse og regionale eiendomsnettverk, samtidig som formelle rettigheter holdes analytisk adskilt fra faktisk drift og brukernes vilkår.

Byloven av 1276, lovmanuskriptenes senere kopiering og Hallvardskirkens forbindelse til bispegården prøver norm, praksis, tekstoverlevering og overlappende institusjonsmakt.

Hallvardskirken og Hovedøya knytter kirkelig skriftkultur, diplomer, segl og fragmentarisk arkivoverlevering til konkrete institusjoner uten å hevde at skrift erstattet muntlig rettspraksis.

Bjørvika, Middelalderbyen og Mariakirken dokumenterer havn, brygger, skipsrester, byinfrastruktur og kongelig institusjonstopografi som flere sammenvevde drivere i bydannelsen.

## Tilbakeholdt teori

\`theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming\` er ikke kvalifisert. V1 mangler to stedsspesifikke Oslo/Akershus-caser som dokumenterer dødelighet, ødegårder, jordleie, inntektsfall eller institusjonsendring med tilstrekkelig proveniens og alternative forklaringer.

## Autoritetsgrense

Fasen endrer ikke de frosne V5.5-teoriobjektene. \`evidence_ready\` føres bare i V6-registeret og betyr kontraktgyldig dokumentert anvendelse, ikke universelt bevis.
`);

const theoryDocPath = 'docs/HISTORY_THEORY_EVIDENCE.md';
let theoryDoc = fs.readFileSync(path.join(root, theoryDocPath), 'utf8');
theoryDoc = theoryDoc.replace(/Produksjonen står dermed på \d+ av 230\./, `Produksjonen står dermed på ${registry.entries.length} av 230.`);
if (!theoryDoc.includes('Middelalder sosial-, økonomi- og rettsevidens V1:')) {
  theoryDoc = theoryDoc.replace(
    /- Totalt: \*\*\d+ av 230\*\* teoriobjekter \(\*\*[\d,.]+ %\*\*\)\./,
    `- Middelalder sosial-, økonomi- og rettsevidens V1: **5** nye kvalifiserende teoriobjekter, **${newClaims.length}** nye claims og **4** nyvaliderte cases; svartedauden holdes tilbake.\n- Totalt: **${registry.entries.length} av 230** teoriobjekter (**${Math.round(registry.completion.ratio * 1000) / 10} %**).`
  );
}
theoryDoc = theoryDoc.replace(/- Totalt: \*\*\d+ av 230\*\* teoriobjekter \(\*\*[\d,.]+ %\*\*\)\./,
  `- Totalt: **${registry.entries.length} av 230** teoriobjekter (**${Math.round(registry.completion.ratio * 1000) / 10} %**).`);
theoryDoc = theoryDoc.replace(/history-theory-evidence-gap-inventory-v\d+\.md/g, 'history-theory-evidence-gap-inventory-v6.md');
writeText(theoryDocPath, theoryDoc);

writeJson('reports/historie-theory-evidence/medieval-social-v1-validation/materializer-result.json', {
  status: 'MATERIALIZED',
  new_claims: newClaims.length,
  new_sources: newSources.length,
  new_evidence_links: evidenceLinks.length,
  newly_verified_cases: 4,
  expanded_cases: 2,
  qualifying_theories: registry.entries.length,
  ratio: registry.completion.ratio,
  remaining_theories: 230 - registry.entries.length,
  profile: {
    cases: profile.cases.length,
    verified_cases: verifiedCases.length,
    claims: claimsDoc.claims.length,
    sources: sourcesDoc.sources.length,
    evidence_links: evidenceDoc.evidence_links.length
  },
  qualified_theory_ids: Object.keys(theoryBundles),
  held_back_theory_ids: ['theory_his_middelalder_kirke_svartedauden_og_senmiddelalderens_omforming']
});

console.log(JSON.stringify({
  status: 'MATERIALIZED',
  theories: registry.entries.length,
  claims: claimsDoc.claims.length,
  sources: sourcesDoc.sources.length,
  evidence: evidenceDoc.evidence_links.length,
  verified_cases: verifiedCases.length
}, null, 2));
