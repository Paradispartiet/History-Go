import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const ROOT = process.cwd();
const configs = [
  {
    "id": "langebudalen_naturreservat",
    "path": "data/places/natur/vestland/langebudalen_naturreservat.json",
    "title": "Langebudalen naturreservat",
    "year": 2000,
    "designCode": "article_nature_yew_microclimate_miniature",
    "nature_summary": "Langebudalen er eit botanisk særtilfelle der barlind veks omkring 550–600 meter over havet. Den skjerma dalforma reduserer påverknaden frå kjølige vindar, store granittmassar kan lagre varme, og eit tjukt, stabilt snødekke har forma mange individ til låg, fleirstamma og krypande vekst. Rundinga koplar mikroklimaet til den dokumenterte kystfloraen og til vernet: all vegetasjon i naturreservatet er freda og skal observerast utan plukking eller skade.",
    "underbadges": [
      "botanikk",
      "biologisk_mangfold",
      "naturvern",
      "skog"
    ],
    "tasks": [
      {
        "title": "Forklar kvifor barlinda kan vekse så høgt",
        "instruction": "Frå eksisterande, lovleg ferdselslinje: bruk terrengforma du kan sjå og forklar korleis ly mot kjølig vind og varmelagring i granitt kan gi eit gunstigare mikroklima. Hald deg på trygg ferdsel og gå ikkje ut i verna vegetasjon.",
        "why": "Oppgåva knyter den uvanlege høgda til lokale klimaforhold i staden for til ein generell regel om barlind."
      },
      {
        "title": "Les vekstforma som snøtilpassing",
        "instruction": "Observer barlind eller skogstruktur på avstand dersom ho er synleg, og forklar kvifor låg, fleirstamma eller krypande vekst kan vere ein fordel under eit tjukt og stabilt snødekke. Ikkje plukk, knekk eller flytt plantedelar.",
        "why": "Vekstforma er eit av dei mest stadsspesifikke trekka ved Langebudalen."
      },
      {
        "title": "Kopla seks kystplanter til miljøet",
        "instruction": "Bruk stadskortet og kjeldene til å plassere bjønnkam, heisiv, kystmaure, smørtelg, rome og klokkelyng i miljøet med næringsfattig skog og hei. Du skal ikkje leite deg inn i vegetasjonen eller samle eksemplar.",
        "why": "Oppgåva utvidar rundinga frå eitt tre til den dokumenterte kystfloraen rundt barlinda."
      },
      {
        "title": "Les vernet som ei grense for handling",
        "instruction": "Forklar med eigne ord kva det betyr at all vegetasjon er freda: observasjon er målet, medan plukking, skade og samling av plantedelar ikkje er ein del av rundinga.",
        "why": "Naturvern blir gjort konkret gjennom kva spelaren faktisk skal og ikkje skal gjere på staden."
      }
    ],
    "training": [
      {
        "title": "Tre mikroklimastopp",
        "instruction": "Gjer tre korte stopp på same lovlege ferdselslinje og merk deg vind, sol og bergflate utan å gå inn i vegetasjonen.",
        "duration_minutes": 8,
        "intensity": "lett",
        "why": "Trenar evna til å lese små klimaskilnader i terrenget."
      },
      {
        "title": "Høgde og form",
        "instruction": "Bruk fem rolige minutt på å samanlikne høg skogstruktur med låg eller krypande vegetasjon som er synleg frå trygg ferdsel.",
        "duration_minutes": 5,
        "intensity": "lett",
        "why": "Gjer samanhengen mellom eksponering, snø og vekstform lettare å hugse."
      },
      {
        "title": "Seks-plante minnetrening",
        "instruction": "Stå i ro og nemn dei seks dokumenterte kystplantene utan å oppsøke eller røre dei: bjønnkam, heisiv, kystmaure, smørtelg, rome og klokkelyng.",
        "duration_minutes": 4,
        "intensity": "lett",
        "why": "Byggjer botanisk stadskunnskap utan inngrep i reservatet."
      }
    ],
    "training_safety": "Bruk berre eksisterande og lovleg ferdselslinje. Kartankeret er ikkje eit inngangspunkt. All vegetasjon er freda; ikkje plukk, knekk, grav, samle eller tråkk inn i vegetasjonen for å løyse ei oppgåve.",
    "civ_titles": [
      "Høgdeprofil for barlind",
      "Granitt og mikroklima-modell",
      "Snøforma barlind-brikke",
      "Seks kystplanter feltkort"
    ],
    "civ_use": [
      "barlind ved høgdegrensa",
      "mikroklima",
      "snøtilpassing",
      "verna vegetasjon"
    ],
    "brands": [
      [
        "miljodirektoratet",
        "Miljødirektoratet",
        "public_authority"
      ],
      [
        "lovdata",
        "Lovdata",
        "public_legal_source"
      ],
      [
        "kringom",
        "Kringom",
        "cultural_knowledge_source"
      ],
      [
        "langebudalen_naturreservat",
        "Langebudalen naturreservat",
        "natural_system"
      ]
    ],
    "for_na": {
      "title": "Langebudalen: før og no",
      "before": "Den høgtliggjande barlindforekomsten utvikla seg i ein skjerma dal der granitt, snø og lokalklima gav uvanlege vekstvilkår lenge før området fekk formelt vern.",
      "now": "Sidan 13. oktober 2000 er Langebudalen naturreservat verna, og all vegetasjon i reservatet er freda. Staden skal lesast gjennom observasjon utan plukking eller skade.",
      "change": "Formelt vern gjorde den uvanlege barlindforekomsten og resten av vegetasjonen til eit tydeleg forvalta naturmiljø, medan dei fysiske prosessane som forklarer forekomsten framleis kan lesast i terrenget.",
      "lookFor": [
        "barlind 550–600 moh.",
        "skjerma dalrom",
        "granittberg",
        "snøtilpassa vekstform"
      ]
    },
    "story_title": "Barlinda som fann eit varmt rom høgt i fjellet",
    "story_summary": "I Langebudalen møtest høgde, granitt, ly og snø på ein måte som har gjort det mogleg for barlind å vekse uvanleg høgt. Vernet gjer heile vegetasjonen til noko spelaren skal lese, ikkje samle.",
    "story": "Langebudalen naturreservat er lite i areal, men stort som naturhistorisk forklaring. Omkring 550–600 meter over havet veks barlind langt høgare enn ein vanlegvis ventar. Det særmerkte ligg ikkje berre i sjølve arten, men i kombinasjonen av terreng og lokalklima. Dalen ligg skjerma mot kjølige vindar, og store granittmassar kan ta opp varme og gi frå seg varme att. Slik kan eit lite rom i landskapet få andre vekstvilkår enn høgda åleine skulle tilseie.\n\nSnøen er den andre delen av historia. Eit tjukt og stabilt snødekke pressar og skjermer vegetasjonen gjennom vinteren. I Langebudalen har barlinda derfor ikkje berre den forma mange kjenner frå lågare område. Ho kan vere låg, fleirstamma og krypande. Vekstforma blir eit spor etter klimaet: treet viser i kroppen korleis det har møtt snø, kulde og terreng over lang tid.\n\nRundt barlinda finst ei dokumentert kystflora frå næringsfattig skog og hei. Bjønnkam, heisiv, kystmaure, smørtelg, rome og klokkelyng gjer det mogleg å lese reservatet som meir enn ein einskild art. Dei peikar mot eit vestleg, fuktig naturmiljø der kystpreg og høgde møtest. Poenget er ikkje at spelaren skal finne og samle alle plantene, men at namna kan brukast til å forstå kva slags vegetasjon kjeldene faktisk dokumenterer.\n\nVernet frå 2000 set ei tydeleg grense rundt denne læringa: all vegetasjon er freda. History Go-rundinga skal derfor ikkje lokke spelaren bort frå eksisterande ferdselslinjer, og ho skal aldri premiere plukking, knekte greiner eller innsamling. Den mest presise måten å oppleve Langebudalen på er å sjå samanhengen mellom dalform, berg, snø og plantevekst. Då blir den høgtliggjande barlinda eit konkret bevis på at naturgrenser ikkje berre blir bestemte av meter over havet, men av dei små klimatiske romma som landskapet skaper.",
    "sources": [
      [
        "Kringom – Langebudalen",
        "https://kringom.no/nb/sunnhordland/etne/langebudalen"
      ],
      [
        "Lovdata – fredningsforskriften",
        "https://lovdata.no/forskrift/2000-10-13-1022"
      ],
      [
        "Miljødirektoratet – naturvernområde",
        "https://faktaark.naturbase.no/?id=VV00001065"
      ]
    ],
    "facts": [
      "Langebudalen naturreservat blei verna 13. oktober 2000.",
      "Reservatet omfattar om lag 17 dekar.",
      "Barlind veks omkring 550–600 meter over havet i området.",
      "Forekomsten er uvanleg høgtliggjande for barlind.",
      "Den skjerma dalen reduserer påverknaden frå kjølige vindar.",
      "Store granittmassar kan bidra til eit lokalt varmare mikroklima.",
      "Stabilt snødekke er knytt til låg, fleirstamma og krypande vekstform.",
      "Bjønnkam er dokumentert i kystfloraen rundt forekomsten.",
      "Heisiv, kystmaure, smørtelg, rome og klokkelyng er også dokumenterte.",
      "All vegetasjon i naturreservatet er freda.",
      "Kartpunktet er eit representativt områdeanker, ikkje ein inngang eller parkeringsplass."
    ],
    "wiki": [
      "Langebudalen naturreservat ligg i Etne og blei verna i 2000.",
      "Barlinda veks omkring 550–600 meter over havet, uvanleg høgt for arten.",
      "Skjerma terreng og varmelagrande granitt er del av forklaringa på det gunstige mikroklimaet.",
      "Stabil snø er knytt til låg, fleirstamma og krypande vekstform.",
      "Kringom dokumenterer fleire kystplanter i den næringsfattige skogen og heia.",
      "All vegetasjon er freda, så rundinga skal løysast gjennom observasjon utan inngrep."
    ]
  },
  {
    "id": "saevareidberget_landskapsvernomrade",
    "path": "data/places/natur/vestland/saevareidberget_landskapsvernomrade.json",
    "title": "Sævareidberget landskapsvernområde",
    "year": 1984,
    "designCode": "article_nature_pollarded_woodland_miniature",
    "nature_summary": "Sævareidberget er ein kulturpåverka edellauvskog der mange hundre gamle styvingstre viser korleis gjenteken lauving forma både tre og landskap. Ask, alm og lind blei skorne tilbake for å gi lauvfôr til vinteren, og den langvarige bruken skapte grove stammer, hulrom, mose og strukturar som også har verdi som habitat. Vernet må derfor forståast som vern av eit samspel mellom natur og historisk drift, ikkje som vern av ein urørt skog.",
    "underbadges": [
      "botanikk",
      "biologisk_mangfold",
      "naturvern",
      "skog",
      "kulturlandskap"
    ],
    "tasks": [
      {
        "title": "Kjenn att forma etter styving",
        "instruction": "Frå eksisterande og trygg ferdselslinje: sjå etter tre med grove stammer og gjentekne greinfeste eller knudrete kroner. Forklar korleis forma kan vere resultat av gjenteken styving, utan å gå bort til eller klatre i gamle tre.",
        "why": "Styvinga er det mest stadsspesifikke sporet etter historisk bruk i Sævareidberget."
      },
      {
        "title": "Forklar lauving som vinterfôr",
        "instruction": "Forklar med eigne ord korleis gjenteken hausting av greiner og lauv frå ask, alm og lind kunne gi vinterfôr, og kvifor ein måtte kome tilbake til dei same trea over tid. Ikkje kutt eller bryt greiner.",
        "why": "Oppgåva koplar treforma til den praktiske ressursbruken som skapte kulturlandskapet."
      },
      {
        "title": "Skil kulturpåverka skog frå urørt skog",
        "instruction": "Finn tre synlege trekk som kan passe med langvarig menneskeleg bruk, til dømes styvingsform, opnare skogstruktur eller gamle driftsflater. Registrer berre det du faktisk kan sjå frå trygg ferdsel.",
        "why": "Vernet gir mest meining når skogen blir lesen som eit historisk forma system."
      },
      {
        "title": "Les gamle tre som habitat",
        "instruction": "På avstand: sjå etter grove stammer, mose, hulrom eller død ved som er synleg utan å forlate ferdselslinja. Forklar kvifor lang kontinuitet i gamle tre kan gi fleire leveområde. Ikkje klatre eller rør ustabile kroner.",
        "why": "Kulturhistorisk bruk og biologisk mangfald møtest i strukturen til dei gamle trea."
      }
    ],
    "training": [
      {
        "title": "Treform-intervall",
        "instruction": "Gå roleg i åtte minutt på trygg ferdsel og stopp tre gonger for å samanlikne treformer utan å gå inn i den bratte skogen.",
        "duration_minutes": 8,
        "intensity": "lett",
        "why": "Trenar blikket for spor etter styving og lang tids bruk."
      },
      {
        "title": "Ask, alm og lind-minne",
        "instruction": "Stå i ro og repeter dei tre dokumenterte treslaga og rolla deira i lauvinga: ask, alm og lind.",
        "duration_minutes": 4,
        "intensity": "lett",
        "why": "Festar dei stadsspesifikke treslaga til driftsforma."
      },
      {
        "title": "Landskapslesing i fire ledd",
        "instruction": "Peik ut eit trygt utsyn og beskriv rekkja treform, tidlegare bruk, dagens habitat og vern utan å gå nærare gamle tre.",
        "duration_minutes": 6,
        "intensity": "lett",
        "why": "Bind saman kulturhistorie og naturvern i éi observasjonsøving."
      }
    ],
    "training_safety": "Området er bratt. Bruk berre trygg, eksisterande ferdsel og følg lokal skilting. Gamle, overgrodde trekroner kan vere tunge og ustabile; ikkje klatre, hogg, kutt greiner eller gå under terreng og kroner som verkar utrygge.",
    "civ_titles": [
      "Styvingstre livsløpsmodell",
      "Ask–alm–lind samanlikningskort",
      "Lauving og vinterfôr-brikke",
      "Kulturpåverka skog relieff"
    ],
    "civ_use": [
      "styving",
      "lauving",
      "ask alm lind",
      "kulturlandskap og habitat"
    ],
    "brands": [
      [
        "miljodirektoratet",
        "Miljødirektoratet",
        "public_authority"
      ],
      [
        "lovdata",
        "Lovdata",
        "public_legal_source"
      ],
      [
        "kringom",
        "Kringom",
        "cultural_knowledge_source"
      ],
      [
        "saevareidberget_landskapsvernomrade",
        "Sævareidberget landskapsvernområde",
        "natural_system"
      ]
    ],
    "for_na": {
      "title": "Sævareidberget: før og no",
      "before": "Gjennom gjenteken lauving blei greiner og lauv frå ask, alm og lind hausta som vinterfôr. Mange hundre tre blei forma av denne drifta over lang tid.",
      "now": "Sidan 23. november 1984 er området landskapsvernområde. Dei gamle styvingstrea blir lesne som både kulturhistoriske spor og biologiske strukturar i ein bratt edellauvskog.",
      "change": "Då den tradisjonelle drifta minka, blei det tydeleg at også eit kulturpåverka skogsystem kan endre seg ved opphøyr av bruk. Vern og skjøtsel handlar derfor om å ta vare på både trea, landskapet og historia om driftsforma.",
      "lookFor": [
        "gamle styvingstre",
        "ask, alm og lind",
        "grove stammer og hulrom",
        "bratt kulturpåverka edellauvskog"
      ]
    },
    "story_title": "Skogen som blei forma med hendene",
    "story_summary": "Sævareidberget ser ut som skog, men mange av dei gamle trea er også arbeidsminne. Gjenteken lauving forma ask, alm og lind og skapte eit kulturlandskap som i dag er verna.",
    "story": "Sævareidberget landskapsvernområde viser kor vanskeleg det kan vere å trekkje ei enkel grense mellom natur og kultur. I den bratte lia ved Åkrafjorden står mange hundre gamle styvingstre. Ask, alm og lind blei ikkje berre ståande urørte gjennom generasjonane. Greiner og lauv blei hausta om att og om att for å skaffe vinterfôr til husdyra. Kvar hausting sette spor i trea, og etter mange rundar fekk dei grove, knudrete stammer og særmerkte kroner.\n\nDenne driftsforma blir kalla lauving, medan sjølve tilbakekappinga av trea blir lesen som styving. Det viktige er rytmen: menneska kom tilbake til dei same trea med års mellomrom. Treet overlevde og skaut nye greiner, og landskapet blei halde ope på ein annan måte enn i ein skog utan slik bruk. Difor er Sævareidberget ikkje best forstått som urørt natur. Det er ein skog der langvarig ressursbruk har blitt ein del av økologien.\n\nDei gamle trea har samtidig fått eigenskapar som kan vere viktige for andre organismar. Grove stammer, hulrom, mose og død ved skaper variasjon i ein skog som elles kunne ha vore meir einsarta. Slik kan eit kulturspor også bli eit habitatspor. Når driftsforma minkar eller stoppar, endrar skogen seg igjen: kroner veks til, gamle greiner blir tyngre, og strukturen som blei halde ved like gjennom bruk kan gradvis forsvinne.\n\nDet gjer vernet frå 1984 meir nyansert enn eit bilete av at mennesket berre skal trekkje seg ut. Sævareidberget er verna fordi det dokumenterer eit kulturpåverka landskap og tradisjonelle driftsformer, samstundes som dei gamle trea har naturverdi. Rundinga skal derfor lære spelaren å lese styvingsforma, forstå lauving som vinterfôr og sjå samanhengen mellom bruk og biologisk mangfald. Men staden er bratt, og gamle overgrodde kroner kan vere tunge og ustabile. Den rette måten å lese dette landskapet på er frå trygg ferdsel, utan klatring, hogst eller inngrep. Då blir dei gamle trea ståande som det dei er: levande arkiv etter eit jordbruk som forma skogen over lang tid.",
    "sources": [
      [
        "Kringom – Stordalen og styvingsskogene",
        "https://kringom.no/nb/sunnhordland/etne/stordalen"
      ],
      [
        "Lovdata – verneforskriften",
        "https://lovdata.no/dokument/LF/forskrift/1984-11-23-1913"
      ],
      [
        "Miljødirektoratet – naturvernområde",
        "https://faktaark.naturbase.no/?id=VV00001587"
      ]
    ],
    "facts": [
      "Sævareidberget landskapsvernområde blei verna 23. november 1984.",
      "Verneområdet dekkjer om lag 250 dekar.",
      "Området er ein kulturpåverka edellauvskog.",
      "Kringom omtaler mange hundre gamle styvingstre i området.",
      "Ask er eit uttrykkeleg dokumentert treslag i styvingsfeltet.",
      "Alm er eit uttrykkeleg dokumentert treslag i styvingsfeltet.",
      "Lind er eit uttrykkeleg dokumentert treslag i styvingsfeltet.",
      "Lauving innebar gjenteken hausting av greiner og lauv til vinterfôr.",
      "Gjenteken styving forma grove og ofte forvridde stammer og kroner.",
      "Gamle tre kan utvikle hulrom, mose og død ved som gir habitatvariasjon.",
      "Området er bratt, og gamle overgrodde kroner kan vere tunge og ustabile.",
      "Kartpunktet er eit områdeanker og ikkje ein anbefalt inngang."
    ],
    "wiki": [
      "Sævareidberget landskapsvernområde ligg i Etne og blei verna i 1984.",
      "Verneformålet er knytt til ein kulturpåverka edellauvskog og tradisjonelle driftsformer.",
      "Mange hundre gamle styvingstre er dokumenterte i området.",
      "Ask, alm og lind blei forma gjennom gjenteken lauving til vinterfôr.",
      "Dei gamle trea kan også gi strukturar som hulrom, mose og død ved.",
      "Rundinga skal lesast frå trygg ferdsel utan klatring, hogst eller inngrep i trea."
    ]
  },
  {
    "id": "jettegrytene_rullestad",
    "path": "data/places/natur/vestland/jettegrytene_rullestad.json",
    "title": "Jettegrytene på Rullestad",
    "year": null,
    "designCode": "article_nature_glacial_potholes_miniature",
    "nature_summary": "Jettegrytene på Rullestad er konkrete spor etter ekstrem smeltevasserosjon ved slutten av siste istid. Vatn under stort trykk sette stein og grus i roterande rørsle mot prekambrisk granitt og slipte ut store, runde groper. Geopark Sunnhordland omtaler 20–30 store jettegryter i området, medan History Go-markøren framleis berre er eit representativt områdeanker som må gjennom manuell visuell QA og ikkje skal brukast som eit presist tilgangspunkt.",
    "underbadges": [
      "geologi",
      "istid",
      "erosjon",
      "landskapsformer"
    ],
    "tasks": [
      {
        "title": "Bygg erosjonsprosessen i fire steg",
        "instruction": "Frå trygg og lovleg ferdsel: forklar rekkja kraftig smeltevatn, roterande rørsle, stein og grus som slipeverktøy, og gradvis utholing av fast fjell. Du treng ikkje stå ved eit eksakt kartpunkt for å løyse oppgåva.",
        "why": "Oppgåva gjer jettegryta til eit resultat av ein prosess, ikkje berre ei rund form i berget."
      },
      {
        "title": "Skil jettegryta frå ein foss",
        "instruction": "Forklar kvifor ei jettegryte er eit erosjonsspor i fast fjell etter roterande vatn og lausmateriale, medan ein foss er eit noverande eller tidlegare fall i eit vassløp. Bruk berre trygt utsyn.",
        "why": "Skiljet hindrar at alle sterke vassprosessar blir blanda saman."
      },
      {
        "title": "Les granitten som arbeidsflate",
        "instruction": "Observer berg som er synleg frå trygg ferdsel og forklar kvifor stein og grus i rørsle kan fungere som slipemiddel mot fast fjell over tid. Ikkje klatre ned i jettegryter eller gå nær utsette kantar.",
        "why": "Materiala i prosessen blir like viktige som vatnet sjølv."
      },
      {
        "title": "Frå istidsvatn til tørt landskap",
        "instruction": "Lag ei før–no-forklaring: først enorme smeltevassmengder under avsmeltinga, deretter eit landskap der den aktive vassruta er borte men erosjonssporet står att. Hald deg til trygg ferdsel og lokal skilting.",
        "why": "Oppgåva viser korleis ein kortvarig prosess kan etterlate eit svært langvarig geologisk spor."
      }
    ],
    "training": [
      {
        "title": "Prosess-sekvens i fire stopp",
        "instruction": "På ei trygg ferdselslinje: gjer fire korte stopp og repeter prosessen vatn, rotasjon, slipemiddel og utholing.",
        "duration_minutes": 6,
        "intensity": "lett",
        "why": "Gjer den geologiske mekanismen lettare å hugse gjennom rytme og rekkjefølgje."
      },
      {
        "title": "Sirkelrørsle utan terrenginngrep",
        "instruction": "Stå på flat, trygg grunn og teikn ei langsam sirkelrørsle med handa medan du forklarer korleis roterande vatn kan halde stein og grus i rørsle.",
        "duration_minutes": 3,
        "intensity": "lett",
        "why": "Visualiserer prosessen utan å krevje tilgang til sjølve jettegrytene."
      },
      {
        "title": "Berg og vatn-landskapslesing",
        "instruction": "Bruk fem minutt på å identifisere bergflate, fallretning og moglege gamle vasspor frå eit trygt utsyn. Registrer berre det du faktisk kan sjå.",
        "duration_minutes": 5,
        "intensity": "lett",
        "why": "Trenar geologisk observasjon utan å gjere det omtrentlege kartankeret til ein ruteinstruks."
      }
    ],
    "training_safety": "Kartpunktet er eit representativt områdeanker med status needs_manual_visual_qa, ikkje eit presist tilgangspunkt. Følg lokal skilting og etablert tilkomst. Området kan vere bratt; ikkje klatre ned i jettegryter, gå nær utsette kantar eller bruk kartnåla som direkte ferdselsinstruks.",
    "civ_titles": [
      "Smeltevatn-vortexmodell",
      "Stein og grus slipebrikker",
      "11 000-års tidskort",
      "Rullestad jettegryte-relieff"
    ],
    "civ_use": [
      "smeltevasserosjon",
      "roterande vatn",
      "stein og grus som slipemiddel",
      "landskap etter istida"
    ],
    "brands": [
      [
        "geopark_sunnhordland",
        "Geopark Sunnhordland",
        "geological_knowledge_source"
      ],
      [
        "etne_kommune",
        "Etne kommune",
        "public_authority"
      ],
      [
        "jettegrytene_rullestad",
        "Jettegrytene på Rullestad",
        "natural_system"
      ],
      [
        "rullestad_landscape",
        "Rullestad-landskapet",
        "natural_system"
      ]
    ],
    "for_na": {
      "title": "Jettegrytene: før og no",
      "before": "Ved slutten av siste istid førte rask avsmelting enorme vassmengder gjennom Rullestad-området. Vatn under stort trykk sette stein og grus i rørsle og slipte store groper i granitten.",
      "now": "Den aktive smeltevassruta er borte, men 20–30 store jettegryter står att som geologiske prosesspor i landskapet. Tilkomsten kan vere bratt og skal følgje lokal skilting.",
      "change": "Vatnet som gjorde erosjonsarbeidet forsvann då avsmeltinga og dreneringsmønsteret endra seg, medan forma i det faste fjellet blei ståande som eit varig arkiv etter den kortvarige prosessen.",
      "lookFor": [
        "runde erosjonsformer",
        "granitt",
        "spor etter kraftig vatn",
        "samanhengen mellom prosess og landform"
      ]
    },
    "story_title": "Då smeltevatnet bora i granitten",
    "story_summary": "Jettegrytene på Rullestad viser korleis ei kort og ekstrem smeltevassfase ved slutten av siste istid kunne slipe store, runde groper i fast granitt og etterlate spor som framleis kan lesast i landskapet.",
    "story": "Jettegrytene på Rullestad ser ut som om nokon har bora enorme hol i fjellet, men verktøyet var vatn, stein, grus og tid under ekstremt trykk. Geopark Sunnhordland omtaler 20–30 store jettegryter i området, innskorne i prekambrisk granitt. Dei blir knytte til den raske avsmeltinga ved slutten av siste istid, då enorme vassmengder fann vegar gjennom og under den minkande isen.\n\nVatnet åleine forklarer ikkje den runde forma. Når straumen blei pressa inn i virvlar, kunne stein og grus bli haldne i roterande rørsle mot berggrunnen. Lausmaterialet fungerte då som slipemiddel. Kvar runde tok litt av fjellet, og over tid kunne ei ujamn fordjuping bli djupare og meir sirkulær. Det er denne mekanismen som gjer jettegryta til noko anna enn berre eit hol eller ein liten kulp: forma er sjølve avtrykket etter ein bestemt erosjonsprosess.\n\nDet mest fascinerande er kontrasten mellom kor kort prosessen kan ha vore og kor lenge sporet blir ståande. Geoparken framhevar at den sterke smeltevassfasen høyrer til den raske tilbaketrekkinga av innlandsisen for om lag elleve tusen år sidan. Då isen og dreneringsvegane endra seg, forsvann vassmengdene som hadde gjort arbeidet. Granitten blei liggjande att med groper som viser kor vatnet ein gong hadde kraft nok til å flytte stein som slipeverktøy.\n\nHistory Go-rundinga skal derfor handle om å rekonstruere prosessen: smeltevatn, rotasjon, stein og grus, slitasje og eit fjellspor som overlever vatnet som skapte det. Samtidig må kartet behandlast presist. Den lagra markøren er eit representativt områdeanker med behov for manuell visuell QA, ikkje eit eksakt punkt for ei bestemt jettegryte og ikkje ein ferdselsinstruks. Geoparken opplyser dessutan at tilkomsten er bratt. Spelaren skal følgje etablert tilkomst og lokal skilting, halde avstand til utsette kantar og aldri måtte klatre ned i ei jettegryte for å fullføre rundinga. Slik blir staden både eit sterkt geologisk læringspunkt og eit døme på at gode naturdata også må vere ærlege om kva kartnåla faktisk veit.",
    "sources": [
      [
        "Geopark Sunnhordland – lokalitetar",
        "https://www.geoparksunnhordland.no/lokalitetar/"
      ],
      [
        "Etne kommune – naturforvaltning",
        "https://www.etne.kommune.no/naring-natur-og-miljo/natur-og-miljovern/naturforvaltning/"
      ]
    ],
    "facts": [
      "Jettegrytene på Rullestad er ein kvartærgeologisk lokalitet i Etne.",
      "Geopark Sunnhordland omtaler 20–30 store jettegryter i området.",
      "Jettegrytene er skorne inn i prekambrisk granitt.",
      "Danninga er knytt til rask avsmelting ved slutten av siste istid.",
      "Kraftige smeltevassmengder var ein sentral del av erosjonsprosessen.",
      "Roterande vatn kunne halde stein og grus i rørsle mot berggrunnen.",
      "Stein og grus fungerte som slipemiddel i den faste granitten.",
      "Dei runde gropene kan stå att lenge etter at den aktive vassruta er borte.",
      "Etne kommune nemner jettegrytene som ein geologisk lokalitet med særskilde kvalitetar.",
      "Geopark Sunnhordland opplyser at tilkomsten er bratt.",
      "Kartpunktet er eit representativt områdeanker, ikkje eit eksakt punkt for éi bestemt jettegryte.",
      "Koordinatstatusen skal framleis vere needs_manual_visual_qa til manuell visuell kontroll er gjennomført."
    ],
    "wiki": [
      "Jettegrytene på Rullestad er store erosjonsformer i fast granitt.",
      "Geopark Sunnhordland omtaler 20–30 store jettegryter i lokaliteten.",
      "Dei blei danna av kraftig smeltevatn under den raske avsmeltinga ved slutten av siste istid.",
      "Stein og grus i roterande vatn fungerte som slipemiddel mot berggrunnen.",
      "Etne kommune fører jettegrytene som ein geologisk lokalitet med særskilde kvalitetar.",
      "History Go-markøren er framleis eit representativt områdeanker som treng manuell visuell QA."
    ]
  }
];
const storyPath = "data/stories/stories_etne_natur_rounds_batch9.json";
const lexPath = "data/leksikon/places/vestland/etne/natur/leksikon_etne_natur_rounds_batch9.json";
const testPath = "tests/etne-natur-rounds-batch9.test.js";
const reportDir = "reports/etne-natur-rounds-batch9";
const payloadFiles = Array.from({ length: 8 }, (_, i) => `scripts/.etne-batch9-payload-${i + 1}.b64`);

function readJson(rel) { return JSON.parse(fs.readFileSync(path.join(ROOT, rel), "utf8")); }
function writeJson(rel, value) {
  const abs = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, JSON.stringify(value, null, 2) + "\n");
}
function slug(s) { return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/æ/g,"ae").replace(/ø/g,"o").replace(/å/g,"a").replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g, ""); }

function makeCiv(c) {
  return c.civ_titles.map((title, i) => ({
    id: `${c.id}_civ_${i + 1}`,
    title,
    type: i === 0 ? "relieffmodell" : i === 1 ? "modell" : i === 2 ? "metallbrikke" : "feltkort",
    kind: "physical_object",
    desc: `Eit fysisk samleobjekt som visualiserer eit dokumentert trekk ved ${c.title}.`,
    placeSpecificReason: `Objektet er direkte knytt til ${c.title} sine dokumenterte naturprosessar, brukshistorie eller vernegrenser.`,
    historicalFunction: "Gjer stadsspesifikk naturkunnskap fysisk samlbar utan inngrep på staden.",
    physicalObject: true,
    placeSpecific: true,
    storePrice: [40, 30, 20, 25][i],
    currency: "PC",
    collection: c.id,
    collectable: true,
    civicationUse: c.civ_use,
    source_urls: c.sources.map(x => x[1])
  }));
}
function makeBrands(c) { return c.brands.map(([id,name,brand_kind]) => ({ id, name, brand_kind, brand_type: "place_specific_actor_or_context" })); }
function storyFor(c) {
  return {
    id: `st_${c.id}_batch9`, type: "environmental", title: c.story_title, year: c.year,
    place_id: c.id, person_id: null, summary: c.story_summary, story: c.story,
    sources: c.sources.map(([title,url]) => ({ title, url })),
    tags: [slug(c.title), ...c.civ_use.map(slug)], related_people: [],
    related_places: c.id === "langebudalen_naturreservat" ? ["jettegrytene_rullestad","postvegen_rullestadjuvet","langfoss_etne"] : c.id === "saevareidberget_landskapsvernomrade" ? ["langebudalen_naturreservat","langfoss_etne","postvegen_rullestadjuvet"] : ["postvegen_rullestadjuvet","langebudalen_naturreservat","langfoss_etne"],
    score: { narrative:5, historical:5, source:5, play_value:5, originality:5, total:25 },
    arc: { start:c.story_summary, middle:c.for_na.change, end:c.training_safety },
    next_scenes: []
  };
}
function lexFor(c) {
  const sourceLabels = c.sources.map(x => x[0]);
  return {
    place_id: c.id,
    visual: { designCode: c.designCode },
    version: 2,
    title: c.title,
    popupDesc: readJson(c.path)[0].popupDesc,
    wikiText: c.wiki,
    summary: { one_liner: c.story_summary, themes: c.civ_use, tone:["nøktern","faglig","stedsspesifikk","sikkerhetsstyrt"] },
    facts: c.facts.map((desc,i) => ({ id:`fact_${c.id}_${String(i+1).padStart(2,"0")}`, label:desc, desc, confidence:"high", sources:sourceLabels })),
    chronology: [
      { id:`chrono_${c.id}_01`, year:c.year, period: readJson(c.path)[0].period, desc:c.for_na.before, confidence:"high", sources:sourceLabels },
      { id:`chrono_${c.id}_02`, year:2026, period:"Komplett rundingsprofil", desc:c.for_na.now, confidence:"high", sources:["History Go place data"] }
    ],
    sources: c.sources.map(([label,url],i) => ({ id:`source_${c.id}_${i+1}`, label, type:"external_reference", url, confidence:"high" })),
    interpretation: { what_to_notice:c.for_na.lookFor, why_it_matters:[c.for_na.change,c.story_summary], counterpoints:[c.training_safety] },
    links: { entry_ids:[`st_${c.id}_batch9`], related_places: storyFor(c).related_places, related_people:[] }
  };
}

for (const c of configs) {
  const data = readJson(c.path);
  if (!Array.isArray(data) || !data[0] || data[0].id !== c.id) throw new Error(`Unexpected place file: ${c.path}`);
  const p = data[0];
  p.nature_profile = { ...p.nature_profile, summary: c.nature_summary };
  p.underbadge_ids = c.underbadges;
  p.tasks_profile = { title:`Utforsk ${c.title} presist`, summary:"Fire stadsspesifikke oppgåver som kan løysast utan inngrep eller utrygg ferdsel.", tasks:c.tasks.map((x,i)=>({ id:`${c.id}_task_${i+1}`, ...x })) };
  p.training_profile = { title:`Rolig stadstrening ved ${c.title}`, summary:"Tre lågintensive øvingar for observasjon og stadskunnskap.", safety:c.training_safety, exercises:c.training.map((x,i)=>({ id:`${c.id}_training_${i+1}`, ...x })) };
  p.civication_store = makeCiv(c);
  p.brands = makeBrands(c);
  p.for_na = { ...c.for_na, sources:c.sources.map(x=>x[1]) };
  delete p.rounds;
  delete p.rundinger;
  if (c.id === "jettegrytene_rullestad") {
    if (p.coordStatus !== "needs_manual_visual_qa") throw new Error("Jettegrytene coordinate status changed before batch 9");
    p.externalLinks = [
      { type:"reference", label:"Geopark Sunnhordland – lokalitetar", url:"https://www.geoparksunnhordland.no/lokalitetar/", lang:"nn", verifiedAt:"2026-07-23" },
      { type:"official", label:"Etne kommune – naturforvaltning", url:"https://www.etne.kommune.no/naring-natur-og-miljo/natur-og-miljovern/naturforvaltning/", lang:"nn", verifiedAt:"2026-07-23" }
    ];
  }
  writeJson(c.path, data);
}

writeJson(storyPath, configs.map(storyFor));
const storyManifest = readJson("data/stories/stories_manifest.json");
if (!Array.isArray(storyManifest.files)) throw new Error("Unexpected stories manifest shape");
if (!storyManifest.files.some(x => x.path === storyPath)) storyManifest.files.push({ category:"natur", entity_id:"etne_natur_rounds_batch9", path:storyPath });
writeJson("data/stories/stories_manifest.json", storyManifest);

writeJson(lexPath, configs.map(lexFor));
const lexManifest = readJson("data/leksikon/manifest.json");
if (!Array.isArray(lexManifest.files)) throw new Error("Unexpected leksikon manifest shape");
if (!lexManifest.files.includes(lexPath)) lexManifest.files.push(lexPath);
writeJson("data/leksikon/manifest.json", lexManifest);

const test = `const fs=require('fs'),assert=require('assert');
` +
`const paths={langebudalen_naturreservat:'data/places/natur/vestland/langebudalen_naturreservat.json',saevareidberget_landskapsvernomrade:'data/places/natur/vestland/saevareidberget_landskapsvernomrade.json',jettegrytene_rullestad:'data/places/natur/vestland/jettegrytene_rullestad.json'};
` +
`const ids=Object.keys(paths);for(const id of ids){const p=JSON.parse(fs.readFileSync(paths[id],'utf8'))[0];assert.ok(p.tasks_profile.tasks.length>=4,id+' tasks');assert.ok(p.nature_profile.summary.length>=100,id+' nature');assert.ok(p.underbadge_ids?.length>=3,id+' badges');assert.ok(p.training_profile.exercises.length>=3,id+' training');assert.ok(p.civication_store.length>=4,id+' civ');assert.ok(p.brands.length>=4,id+' brands');assert.ok(p.for_na.before&&p.for_na.now&&p.for_na.change,id+' forna');assert.ok(!p.rounds&&!p.rundinger,id+' override');}
` +
`const s=JSON.parse(fs.readFileSync('${storyPath}','utf8')),l=JSON.parse(fs.readFileSync('${lexPath}','utf8'));for(const id of ids){assert.ok(s.some(x=>x.place_id===id&&x.story.length>=900),id+' story');const a=l.find(x=>x.place_id===id);assert.ok(a&&a.wikiText.length>=5&&a.facts.length>=10,id+' lex');}
` +
`const a=JSON.parse(fs.readFileSync(paths.langebudalen_naturreservat,'utf8'))[0];assert.ok(/550–600/.test(a.nature_profile.summary),'Langebudalen altitude');assert.ok(/all vegetasjon|all vegetasjonen/i.test(a.for_na.now+a.training_profile.safety),'Langebudalen vegetation protection');
` +
`const b=JSON.parse(fs.readFileSync(paths.saevareidberget_landskapsvernomrade,'utf8'))[0];assert.ok(/styving/.test(b.nature_profile.summary)&&/lauving/.test(b.for_na.before),'Saevareidberget use');assert.ok(/ikkje klatre|ikke klatre/i.test(b.training_profile.safety)&&/ikkje.*hogg|ikke.*hogg/i.test(b.training_profile.safety),'Saevareidberget safety');
` +
`const j=JSON.parse(fs.readFileSync(paths.jettegrytene_rullestad,'utf8'))[0];assert.strictEqual(j.coordStatus,'needs_manual_visual_qa','Jettegrytene coord status');assert.ok(/smeltevatn|smeltevann/i.test(j.nature_profile.summary),'Jettegrytene meltwater');assert.ok(j.tasks_profile.tasks.every(x=>!/eksakt kartpunkt|gå til kartnåla/i.test(x.instruction)||/treng ikkje stå ved eit eksakt kartpunkt/i.test(x.instruction)),'Jettegrytene no pin dependency');assert.ok(/representativt områdeanker/.test(j.training_profile.safety),'Jettegrytene anchor caveat');
` +
`console.log('Etne nature rounds batch 9 OK');
`;
fs.mkdirSync(path.dirname(path.join(ROOT,testPath)),{recursive:true});
fs.writeFileSync(path.join(ROOT,testPath),test);
fs.mkdirSync(path.join(ROOT,reportDir),{recursive:true});
fs.writeFileSync(path.join(ROOT,reportDir,"summary.md"),`# Etne natur-rundinger batch 9\n\nSteder: ${configs.map(c=>c.id).join(", ")}\n\n- Oppgaver, naturprofil, underbadges, trening, Civication Store, brands og før/nå er fylt ut.\n- Story- og leksikonfiler er registrert i manifestene.\n- Jettegrytene beholder coordStatus needs_manual_visual_qa.\n- Ingen rounds/rundinger-overstyringer er beholdt.\n`);
const t = spawnSync(process.execPath,[path.join(ROOT,testPath)],{encoding:"utf8"});
fs.writeFileSync(path.join(ROOT,reportDir,"test.log"),(t.stdout||"")+(t.stderr||""));
if (t.status !== 0) throw new Error(`Batch 9 test failed with exit ${t.status}`);
fs.writeFileSync(path.join(ROOT,reportDir,"production-summary.json"),JSON.stringify({batch:9,places:configs.map(c=>c.id),test:"passed",jettegrytene_coord_status:"needs_manual_visual_qa"},null,2)+"\n");
for (const rel of payloadFiles) { try { fs.rmSync(path.join(ROOT,rel)); } catch {} }
try { fs.rmSync(path.join(ROOT,"scripts/.batch9-connector-test")); } catch {}
console.log("Etne nature rounds batch 9 production complete");
